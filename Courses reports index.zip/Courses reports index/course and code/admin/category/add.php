<?php
   include "../../functions/connect.php";
   extract($_POST);
   
   
   $image= addslashes(file_get_contents($_FILES['image']['tmp_name']));
	$image_name= addslashes($_FILES['image']['name']);
	$image_size= getimagesize($_FILES['image']['tmp_name']);

			
			move_uploaded_file($_FILES["image"]["tmp_name"],"../../images/" . $_FILES["image"]["name"]);			
			$location="../images/" . $_FILES["image"]["name"];

   $sql = mysql_query("INSERT INTO `tbl_category`(`name`, `description`,`image`)  VALUES ('$cat_name','$cat_desc','$location')");

    
                    if($sql==true)
                                  {
                                        echo '<script language="javascript">';
                                        echo 'alert("Successfully Added")';
                                        echo '</script>';
                                        echo '<meta http-equiv="refresh" content="0;url=index.php" />';
                                  }
                        
                        
                    ?>