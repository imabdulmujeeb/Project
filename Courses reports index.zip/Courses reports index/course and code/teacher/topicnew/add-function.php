<?php
 include "../../functions/connect2.php";
 date_default_timezone_set("Asia/Taipei");
                        $datetime=date("Y-m-d h:i:sa");
   extract($_POST);
  $sql = mysql_query("INSERT INTO `tbl_topic`(`title`, `content`, `datetime_posted`, `subject_Id`) VALUES ('$title','$content','$datetime','$category')");

  if($sql==true)
      {
            echo '<script language="javascript">';
            echo 'alert("Successfully Added ")';
            echo '</script>';
            echo '<meta http-equiv="refresh" content="0;url=../../../electronictutor/videolecture.php?cat_Id='.$category.'"/>';
      }
	  else
	  {
		  echo mysql_error();
	  }
                        
                        


?>