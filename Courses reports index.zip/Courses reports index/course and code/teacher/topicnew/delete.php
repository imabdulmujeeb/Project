<?php
include "../../functions/connect2.php";
if($_GET['topic_Id'])
{
$id=$_GET['topic_Id'];
$category=$_GET['subject_Id'];
 $sql = "DELETE FROM tbl_topic WHERE topic_Id='$id'";
 mysql_query( $sql);
 
  if($sql==true)
      {
            echo '<script language="javascript">';
            echo 'alert("Successfully DELETED")';
            echo '</script>';
            echo '<meta http-equiv="refresh" content="0;url=../../../electronictutor/videolecture.php?cat_Id='.$category.'"/>';
      }
	  else
	  {
		  echo mysql_error();
	  }
}


?>