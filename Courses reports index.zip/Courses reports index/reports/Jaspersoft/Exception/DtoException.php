<?php

namespace Jaspersoft\Exception;


class DtoException extends \Exception {

} 