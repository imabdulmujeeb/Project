<?php

namespace Jaspersoft\Exception;


class MissingValueException extends \Exception
{

}