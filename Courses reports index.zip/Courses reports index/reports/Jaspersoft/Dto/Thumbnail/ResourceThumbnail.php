<?php

namespace Jaspersoft\Dto\Thumbnail;

use Jaspersoft\Dto\DTOObject;

class ResourceThumbnail extends DTOObject
{

    public $uri;
    public $thumbnailData;



}