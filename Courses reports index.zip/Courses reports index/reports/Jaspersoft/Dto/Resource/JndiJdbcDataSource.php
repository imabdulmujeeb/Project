<?php
namespace Jaspersoft\Dto\Resource;

/**
 * Class JndiJdbcDataSource
 * @package Jaspersoft\Dto\Resource
 */
class JndiJdbcDataSource extends Resource
{
    public $jndiName;
    public $timezone;
}
