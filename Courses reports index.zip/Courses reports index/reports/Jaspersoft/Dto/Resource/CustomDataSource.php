<?php
namespace Jaspersoft\Dto\Resource;

/**
 * Class CustomDataSource
 * @package Jaspersoft\Dto\Resource
 */
class CustomDataSource extends CollectiveResource
{
    public $serviceClass;
    public $dataSourceName;
    public $properties;
}