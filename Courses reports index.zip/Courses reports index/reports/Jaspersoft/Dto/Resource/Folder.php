<?php
namespace Jaspersoft\Dto\Resource;

/**
 * Class Folder
 * @package Jaspersoft\Dto\Resource
 */
class Folder extends Resource
{
}