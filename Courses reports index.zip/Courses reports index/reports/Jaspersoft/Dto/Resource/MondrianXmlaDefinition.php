<?php
namespace Jaspersoft\Dto\Resource;

/**
 * Class MondrianXmlaDefinition
 * @package Jaspersoft\Dto\Resource
 */
class MondrianXmlaDefinition extends CompositeResource
{
    public $catalog;
    public $mondrianConnection;
}