<?php
namespace Jaspersoft\Dto\Resource;

/**
 * Class ListOfValues
 * @package Jaspersoft\Dto\Resource
 */
class ListOfValues extends CollectiveResource
{
    public $items;
}