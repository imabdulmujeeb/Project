<?php
namespace Jaspersoft\Dto\Resource;

/**
 * Class OlapUnit
 * @package Jaspersoft\Dto\Resource
 */
class OlapUnit extends CompositeResource
{
    public $mdxQuery;
    public $olapConnection;
}