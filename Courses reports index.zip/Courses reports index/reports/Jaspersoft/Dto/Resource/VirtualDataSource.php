<?php
namespace Jaspersoft\Dto\Resource;

/**
 * Class VirtualDataSource
 * @package Jaspersoft\Dto\Resource
 */
class VirtualDataSource extends CollectiveResource
{
    public $subDataSources;
}
