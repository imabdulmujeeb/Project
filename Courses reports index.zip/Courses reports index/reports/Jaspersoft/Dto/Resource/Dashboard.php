<?php
namespace Jaspersoft\Dto\Resource;

/**
 * Class Dashboard
 * @package Jaspersoft\Dto\Resource
 */
class Dashboard extends Resource
{
}