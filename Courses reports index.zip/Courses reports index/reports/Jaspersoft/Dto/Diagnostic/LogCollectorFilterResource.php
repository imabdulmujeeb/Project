<?php

namespace Jaspersoft\Dto\Diagnostic;


use Jaspersoft\Dto\DTOObject;

class LogCollectorFilterResource extends DTOObject
{
    public $uri;
    public $includeDataSnapshot;
}