<?php


namespace Jaspersoft\Dto\Job\Calendar;


class HolidayCalendar extends DatedCalendar {

    public $calendarType = "holiday";


} 