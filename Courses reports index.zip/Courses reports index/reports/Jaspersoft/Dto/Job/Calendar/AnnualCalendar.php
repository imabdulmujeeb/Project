<?php


namespace Jaspersoft\Dto\Job\Calendar;


class AnnualCalendar extends DatedCalendar {

    public $calendarType = "annual";

} 