<?php


namespace Jaspersoft\Dto\Job\Calendar;


class CronCalendar extends BaseCalendar {

    public $cronExpression;

} 