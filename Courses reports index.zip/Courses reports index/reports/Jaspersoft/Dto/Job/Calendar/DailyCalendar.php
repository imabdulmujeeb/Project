<?php


namespace Jaspersoft\Dto\Job\Calendar;


class DailyCalendar extends BaseCalendar {

    public $calendarType = "daily";
    public $invertTimeRange;
    public $rangeEndingCalendar;
    public $rangeStartingCalendar;


} 