<?php


namespace Jaspersoft\Dto\Job\Calendar;


use Jaspersoft\Dto\DTOObject;

class BaseCalendar extends DTOObject {

    public $calendarType = "base";
    public $description;
    public $timeZone;

} 