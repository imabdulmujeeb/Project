<?php


namespace Jaspersoft\Dto\Domain;


class MetaItem extends AbstractMetaEntity {

} 