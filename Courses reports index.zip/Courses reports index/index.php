<?php
header('Location: courselearn/index2.php');
?>