<?php include('header_dashboard.php'); ?>
<?php include('session.php'); ?>
<?php $get_id = $_GET['cat_Id']; ?>
    <body>
		<?php include('navbar_teacher.php'); ?>
        <div class="container-fluid">
            <div class="row-fluid">
				<?php include('videolecturelink.php'); ?>
				 <div class="span8" id="content">
				 <div class="row-fluid">
					    <!-- breadcrumb -->
										<?php $class_query = mysql_query("select * from teacher_class
										LEFT JOIN class ON class.class_id = teacher_class.class_id
										LEFT JOIN subject ON subject.subject_id = teacher_class.subject_id
										where teacher_class_id = '$get_id'")or die(mysql_error());
										$class_row = mysql_fetch_array($class_query);
										$class_id = $class_row['class_id'];
										$school_year = $class_row['school_year'];
										?>
					     <ul class="breadcrumb">
							<li><a href="#"><?php echo $class_row['class_name']; ?></a> <span class="divider">/</span></li>
							<li><a href="#"><?php echo $class_row['subject_code']; ?></a> <span class="divider">/</span></li>
							<li><a href="#">School Year: <?php echo $class_row['school_year']; ?></a> <span class="divider">/</span></li>
							<li><a href="#"><b>Video Lectures</b></a></li>
						</ul>
						 <!-- end breadcrumb -->
				</div>
				<div class="row-fluid">
							<!-- block -->
							<div class="block">
								<div class="navbar navbar-inner block-header">
									<div class="muted pull-left">List of Topic</div>
									 <div class="pull-right">
									 

										  <div class="btn-group">
											<?php echo '<a href="../courselearn/teacher/topicnew/add.php?id='.$get_id.'&name='.$teachername.'"><button class="btn btn-success">Add New <i class="icon-plus icon-white"></i></button></a>'; ?> 
										  </div>
										 
									 

									</div>
								</div>
								<div class="block-content collapse in">
									<div class="span12">
									  
										
										<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example2">
												  <thead>
											<tr>
											   
												<th>ID</th>
												<th>Title</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
											
											<?php
											
										   
										  
											$sql = "SELECT * FROM `tbl_topic` ";
											$run = mysql_query($sql);

											while($row=mysql_fetch_array($run)){
												$id = $row['topic_Id'];
												echo '<tr class="odd gradeX" id="rec">';
												echo "<td>".$row['topic_Id']."</td>";
												echo "<td>".$row['title']."</td>";
												 echo "<td>".
												'<div class="btn-group">
												<button type="button" class="btn btn-default btn-xs dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="500" data-close-others="false">
													Action
												<span class="caret"></span>
												</button>
												<ul class="dropdown-menu pull-right" role="menu">
												<li><a href="../courselearn/teacher/topicnew/edit.php?topic_Id='.$row["topic_Id"].'&id='.$get_id.'&name='.$teachername.'"><span class="glyphicon glyphicon-edit"></span> Edit</a></li>
												<li><a href="../courselearn/teacher/topicnew/delete.php?topic_Id='.$row['topic_Id'].'&subject_Id='.$get_id.'" class="delbutton" title="Click To Delete"><span class="glyphicon glyphicon-trash"></span> Delete</a></li>
												</ul>
												</div>'
														."</td>";
			
												echo "</tr>";
									 
										 
											}
										

											?>
									   
											
										</tbody>
										</table>
									</div>
								</div>
							</div>
							<!-- /block -->
						</div>
                 </div>
                   
                </div>
                    </div>
                </div>
            </div>
		<?php include('footer.php'); ?>
        </div>
		<?php include('script.php'); ?>
		<?php include('class_calendar_script.php'); ?>
    </body>
</html>