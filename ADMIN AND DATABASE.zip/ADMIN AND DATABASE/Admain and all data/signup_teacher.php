<?php include('header.php'); ?>
  <body id="login">
    <div class="container">
	<div class="row-fluid">
	<div class="span6">
	</div>
	<div class="span6">
		<div class="pull-right">
				<?php include('signup_teacher_form.php'); ?>
		</div>
	</div>
    </div>
	s
<?php include('script.php'); ?>
  </body>
</html>