<?php
include('header.php'); 
 include('session.php'); 
   $servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "electronictutor";
		// Create connection
		$conn = mysqli_connect($servername, $username, $password,$dbname);
		$sid=$_SESSION['id'];

?>
<head>
	<style>
table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
	</head>
    <body>
    	<?php include('navbar_student.php'); ?>
        <div class="container-fluid">
            <div class="row-fluid">
            	<?php include('sidebar_datesheet.php'); ?>
                
                <!--/span-->
                <div class="span9" id="content">
								        <div id="block_bg" class="block">
                
								<div class="block-content collapse in">
										<div class="span8">
							<!-- block -->
										<div class="navbar navbar-inner block-header">
											<div class="muted pull-left">DateSheet</div>
										</div>
															<div id='DateSheet'></div>		
										</div>
										
										<div class="span4">
										</div>	
										<div>
											<?php
											$res= mysqli_query($conn,"select class_id from student where student_id=$sid");
											while($row=$res->fetch_assoc())
											{
												$cid= $row['class_id'];
												$resname=mysqli_query($conn,"select class_name from class where class_id=$cid");
												$cname="";
												while($rname=$resname->fetch_assoc())
												{
													$cname=$rname['class_name'];
												}
												$res2=mysqli_query($conn, "select * from datesheet where class_id=$cid");
												if($res2->num_rows>0)
												{
													echo "<table>
      <tr>
          <center><th><h1>$cname</h1></th></center>
    </tr>
      
    <tr>
      <th>SUBJECT</th>
      <th>DATE</th>
      <th>TIME</th>
      <th>Venue</th>
      <th>Invigilator</th>
     </tr>";
     while($row=$res2->fetch_assoc())
     {
     	$sbjct = $row['subject'];
     	$dt=$row['date_time'];
     	$dy= $row['time'];
     	$vn= $row['venue'];
     	$tm=$row['invigilator'];
     echo "<tr>
     <td>$sbjct</td>
     <td>$dt</td>
     <td>$dy</td>
     <td>$vn</td>
     <td>$tm</td>
     </tr>";
     }
echo "</table>";
echo "<br><br><br>";
												}
											}
											?>
										</div>
							<!-- block -->
						
										</div>
                                </div>		
                </div>
            </div>
    
        </div>
    </body>

</html>