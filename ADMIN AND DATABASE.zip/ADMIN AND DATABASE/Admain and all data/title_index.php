				
								<div class="row-fluid">

						<div class="span12">
						
						</div>	
													
							</div>
							<div class="row-fluid">

						<div class="span4">
						<!--<img class="index_logo" src="admin/images/Log.png">-->
						</div>	
						<div class="span8">
						
								<div class="title">
							<p class="chmsc"></p>
							<h3>

							<p style="color:white;"> </p>
						
							</h3>		
						</div>
			
						</div>							
							</div>
				
				<div class="row-fluid">

						<div class="span12">
						<br>
								<div class="motto">
												<p style="color:white;"><b>Online Learning:</b></p>
												<p style="color:white;"><b>Smart, Accessible and Educational</b></p>
												<p style="color:white;"><b>Learn at your own pace</b></p>
								</div>		
						</div>		
				</div>