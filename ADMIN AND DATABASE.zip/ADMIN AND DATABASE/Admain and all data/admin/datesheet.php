<?php
include('header.php'); 
 include('session.php'); 
   $servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "electronictutor";
		// Create connection
		$conn = mysqli_connect($servername, $username, $password,$dbname);
		$classQuery = mysqli_query($conn, "select class_id, class_name from class");
		$mcntQuery = mysqli_query($conn, "SELECT MAX(cnt) mcnt FROM (SELECT class_id, COUNT(*) cnt from subject GROUP BY class_id) tbl1");
		$venueQuery = mysqli_query($conn, "select name from venue");
		$timeSlotsQuery = mysqli_query($conn, "select name from time_slot");
		$mcnt=0;
		$vcnt=$venueQuery->num_rows;
		$tcnt=$timeSlotsQuery->num_rows;
		$timeArr= array();
		$venueArr = array();

		$itrr=0;

		while($row=$venueQuery->fetch_assoc())
		{
			$venueArr[$itrr]= $row['name'];
			$itrr++;
		}

		$itrr=0;

		while($row=$timeSlotsQuery->fetch_assoc())
		{
			$timeArr[$itrr]= $row['name'];
			$itrr++;
		}

		while($row=$mcntQuery->fetch_assoc())
		{
			$mcnt= $row['mcnt'];
		}
		$classArr = array();
		$ite=0;
		while($classRow = $classQuery->fetch_assoc())
		{
			$classArr[$ite]=$classRow['class_id'];
			$ite++;
		}

		if(isset($_POST['gen']))
		{
		  $res= mysqli_query($conn, "delete from datesheet");
		  $teacherQuery= mysqli_query($conn, "select teacher_id, firstname, lastname, department_id from teacher where teacher_stat='Activated'");
		  $teacherCount=0;
	      $teacherArr=array();
          $teacherItr=0;
          $teacherIdArr= array();
          while($row=$teacherQuery->fetch_assoc())
          {
	         $teacherIdArr[$teacherItr]=$row['teacher_id'];
			 $fname=$row['firstname'];
	 		 $lname= $row['lastname'];
	   		 $dept= $row['department_id'];
	         $teacherArr[$teacherItr]=$fname." ".$lname."-".$dept;
	         $teacherCount++;
	         $teacherItr++;
		  }
		  $classCnt=0; 
          while($classCnt!=$ite)
		  {
		  	$classId=$classArr[$classCnt];
		  	$subjectArr= getSubjectsByClass($classId, $conn);
		  	$keyArr=array();
		  	$valArr=array();
		  	$itr=0;
		  	foreach ($subjectArr as $sId => $title){  
               $keyArr[$itr]=$sId;
		  	   $valArr[$itr]=$title;
		  	   $itr++;  
            }
		  $subjectItr=0;
		  while($subjectItr!=$itr)
		  {
		  	$sbjctCmbId=$keyArr[$subjectItr];
		  	$sbjctTxt=$valArr[$subjectItr];
		  	srand(make_seed());
    	  	$rand1= rand(0,$tcnt-1);
		  	$rand2= rand(0,$vcnt-1);
		  	$rand3= rand(0,$teacherCount-1);
		  	//echo $rand1." ".$rand2." ".$rand3."<br>";
		  	$start= strtotime('now');
		  	$cnt=$mcnt+5;
		  	$dateVal= randomDateInRange(strtotime('now'),strtotime('now + '.strval($cnt).' days'));
		  	$myDateTime = DateTime::createFromFormat('Y-m-d', $dateVal);
            $dayVal= $myDateTime->format('D');
		  	$timeTxt= $timeArr[$rand1];
		  	$roomTxt= $venueArr[$rand2];
		  	$tchrCmbId= $teacherIdArr[$rand3];
		  	$tchrCmbTxt= $teacherArr[$rand3];
		  	while(checkDateTimeVenue($timeTxt,$roomTxt,$dateVal,$conn))
		  	{
		  			$rand1= rand(0,$tcnt-1);
		    		$rand2= rand(0,$vcnt-1);	
		    		//echo $rand1." ".$rand2."<br>";
		    		$dateVal= randomDateInRange(strtotime('now'),strtotime('now + '.strval($cnt).' days'));
		  			$timeTxt= $timeArr[$rand1];
		  			$roomTxt= $venueArr[$rand2];	
		  	}
		  	while(checkTimeInvigilator($timeTxt,$tchrCmbId,$conn))
			{
				echo $rand3."<br>";
			  	$rand3= rand(0,$teacherCount-1);
			  	$tchrCmbId= $teacherIdArr[$rand3];
		  	    $tchrCmbTxt= $teacherArr[$rand3];
			}
			if(insertEvent($classId,$sbjctCmbId,$sbjctTxt,$timeTxt,$roomTxt,$tchrCmbId,$tchrCmbTxt,$dateVal,$conn))
			{
				$subjectItr++;
			}
		  }
		  $classCnt++;
		 }
		   header("location:datesheet.php");
		}
         function randomDateInRange($start, $end) {
           $timestamp = mt_rand($start, $end);
           return date("Y-m-d", $timestamp);
         }
         function insertEvent($clsiid,$sbjctCmbiid,$sbjctCmbTxt,$timeTxt, $roomTxt,$tchrCmbiid,$tchrCmbTxt,$dateVal, $conn)
         {
         	$result= mysqli_query($conn,"insert into datesheet (class_id, subject_id,subject,date_time, time, venue, invigilator, invigilator_id) values($clsiid,$sbjctCmbiid, '$sbjctCmbTxt', '$dateVal', '$timeTxt', '$roomTxt','$tchrCmbTxt', $tchrCmbiid )");
         	return $result;
         }
         function getSubjectsByClass($clsId, $conn)
         {
         	$arr=array();
         	$result=mysqli_query($conn,"select subject_id, subject_title from subject where class_id=$clsId");
         	while($row=$result->fetch_assoc())
            {
	          $id=$row['subject_id'];
	          $arr[$id]=$row['subject_title'];
            }
         	return $arr;
         }
         function checkDateTimeVenue($timeTxt,$roomTxt,$dateVal, $conn)
         {
             $result= mysqli_query($conn,"select * from datesheet where time='$timeTxt' and venue ='$roomTxt' and date_time='$dateVal'");
	         $r=false;
	         if($result->num_rows>0)
	         {
		        $r=true;
	         }
	         return $r;
         }
         function checkTimeInvigilator($timeTxt,$tchrCmbiid, $conn)
         {
             $result= mysqli_query($conn,"select * from datesheet where time='$timeTxt' and invigilator_id = $tchrCmbiid");
	         $r=false;
	         if($result->num_rows>0)
	         {
		        $r=true;
	         }
         }
         function make_seed()
         {
  			list($usec, $sec) = explode(' ', microtime());
  			return $sec + $usec * 1000000;
		 }
?>
<head>
	<script src="jquery-3.2.1.min.js" type="text/javascript"></script>
	<style>
table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
	</head>
    <body>
		<?php include('navbar.php') ?>
        <div class="container-fluid">
            <div class="row-fluid">
					<?php include('sidebar_datesheet.php'); ?>
                
                <!--/span-->
                <div class="span9" id="content">
								        <div id="block_bg" class="block">
                
								<div class="block-content collapse in">
										<div class="span8">
							<!-- block -->
										<div class="navbar navbar-inner block-header">
											<div class="muted pull-left">DateSheet</div>
										</div>
															<div id='DateSheet'></div>		
										</div>
										
										<div class="span4">
											<form method="POST" action="">
										<button class="btn btn-success" style="margin-top: 15px" id="gen" name="gen">Generate DateSheet</button>								</form>			

										</div>
							<!-- block -->
							<div>
											<?php
											$res= mysqli_query($conn,"select class_id, class_name from class");
											while($row=$res->fetch_assoc())
											{
												$cid= $row['class_id'];
												$cname=$row['class_name'];
												$res2=mysqli_query($conn, "select * from datesheet where class_id=$cid order by date_time, time asc");
												if($res2->num_rows>0)
												{
													echo "<table>
      <tr>
          <center><th><h1>$cname</h1></th></center>
    </tr>
      
    <tr>
      <th>SUBJECT</th>
      <th>DATE</th>
      <th>TIME</th>
      <th>Venue</th>
      <th>Invigilator</th>
     </tr>";
     while($row=$res2->fetch_assoc())
     {
     	$sbjct = $row['subject'];
     	$dt=$row['date_time'];
     	$dy= $row['time'];
     	$vn= $row['venue'];
     	$tm=$row['invigilator'];
     echo "<tr>
     <td>$sbjct</td>
     <td>$dt</td>
     <td>$dy</td>
     <td>$vn</td>
     <td>$tm</td>
     </tr>";
     }
echo "</table>";
echo "<br><br><br>";
												}
											}
											?>
										</div>
										</div>
                                </div>		
                </div>
            </div>
    
         <?php include('footer.php'); ?>
        </div>
	<?php include('script.php'); ?>
	<?php include('admin_calendar_script.php'); ?>
    </body>

</html>