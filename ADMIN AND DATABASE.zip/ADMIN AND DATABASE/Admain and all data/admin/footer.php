<div class="pull-right">
		<footer>
           <p></p>
        <footer>
</div>