<?php
$host = "localhost";
$user = "root";
$password = "";
$db = "electronictutor";

$con = mysqli_connect($host,$user,$password,$db) or die("Could not connect to database");
?>