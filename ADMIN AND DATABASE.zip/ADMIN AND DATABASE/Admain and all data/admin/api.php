<?php

 $servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "electronictutor";
		$conn = mysqli_connect($servername, $username, $password,$dbname);

$req=$_REQUEST['req'];
if($req=='teacher')
{
	$teacherQuery= mysqli_query($conn, "select teacher_id, firstname, lastname, department_id from teacher where teacher_stat='Activated'");
	$arr=array();
while($row=$teacherQuery->fetch_assoc())
{
	$id=$row['teacher_id'];
	$fname=$row['firstname'];
	$lname= $row['lastname'];
	$dept= $row['department_id'];
	$arr[$id]=$fname." ".$lname."-".$dept;
}
$arr1=json_encode($arr);
echo $arr1;
}
else if($req=='addSubject')
{
	$clsiid=$_REQUEST['clsiid'];
	$clsiidTxt=$_REQUEST['clsiidTxt'];
	$sbjctCmbiid=$_REQUEST['sbjctCmbiid'];
	$sbjctCmbTxt=$_REQUEST['sbjctCmbTxt'];
	$timeiid=$_REQUEST['timeiid'];
	$timeTxt=$_REQUEST['timeTxt'];
	$roomiid=$_REQUEST['roomiid'];
	$roomTxt=$_REQUEST['roomTxt'];
	$tchrCmbiid=$_REQUEST['tchrCmbiid'];
	$tchrCmbTxt=$_REQUEST['tchrCmbTxt'];
	$dateVal=$_REQUEST['dateVal'];

	$result= mysqli_query($conn,"insert into datesheet (class_id, subject_id,subject,date_time, time, venue, invigilator, invigilator_id) values($clsiid, 
		$sbjctCmbiid, '$sbjctCmbTxt', '$dateVal', '$timeTxt', '$roomTxt','$tchrCmbTxt', $tchrCmbiid )");
	$r=false;
	if($result)
	{
		$r=true;
	}
	$r1=json_encode($r);
	    echo $r1;
}
else if($req=='checkClassSubject')
{
	$clsiid=$_REQUEST['clsiid'];
	$sbjctCmbiid=$_REQUEST['sbjctCmbiid'];
	$result= mysqli_query($conn,"select * from datesheet where class_id=$clsiid and subject_id=$sbjctCmbiid");
	$r=false;
	if($result->num_rows>0)
	{
		$r=true;
	}
	$r1=json_encode($r);
	    echo $r1;
}
else if($req=='checkDateTimeVenue')
{
	$timeTxt=$_REQUEST['timeTxt'];
	$roomTxt=$_REQUEST['roomTxt'];
	$dateVal=$_REQUEST['dateVal'];
	$result= mysqli_query($conn,"select * from datesheet where time='$timeTxt' and venue ='$roomTxt' and date_time='$dateVal'");
	$r=false;
	if($result->num_rows>0)
	{
		$r=true;
	}
	$r1=json_encode($r);
	    echo $r1;
}
else if($req=='checkTimeInvigilator')
{
	$timeTxt=$_REQUEST['timeTxt'];
	$tchrCmbiid=$_REQUEST['tchrCmbiid'];
	$result= mysqli_query($conn,"select * from datesheet where time='$timeTxt' and invigilator_id = $tchrCmbiid");
	$r=false;
	if($result->num_rows>0)
	{
		$r=true;
	}
	$r1=json_encode($r);
	    echo $r1;
}
else
{
	$arr=array();
$result=mysqli_query($conn,"select subject_id, subject_title from subject where class_id=$req");
while($row=$result->fetch_assoc())
{
	$id=$row['subject_id'];
	$arr[$id]=$row['subject_title'];
}
$arr1=json_encode($arr);
echo $arr1;

}
?>