<?php include('header.php'); ?>
<?php include('session.php'); 
include ('dbcon.php');
?>
    <body>
		<?php include('navbar.php'); ?>
        <div class="container-fluid">
            <div class="row-fluid">
				<?php include('time_slot_sidebar.php'); ?>
				<div class="span3" id="adduser">
				<?php include('add_time_slot.php'); ?>		   			
				</div>
                <div class="span6" id="">
                     <div class="row-fluid">
                        <!-- block -->
                        <div id="block_bg" class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">time_slot List</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
									<form action="delete_time_slot.php" method="post">
  									<table cellpadding="0" cellspacing="0" border="0" class="table" id="example">
										<a data-toggle="modal" href="#time_slot_delete" id="delete"  class="btn btn-danger" name=""><i class="icon-trash icon-large"></i></a>
													<?php include('modal_delete.php'); ?>
									<thead>
										  <tr>
													<th></th>
													<th>time_slots</th>
													<th></th>
										   </tr>
										</thead>
										<tbody>
										<?php
										$class_query = mysqli_query($con,"select * from time_slot");
										while($class_row = mysqli_fetch_array($class_query)){
										$id = $class_row['name'];
										?>
												
										<tr>
											<td width="30">
											<input id="optionsCheckbox" class="uniform_on" name="selector[]" type="checkbox" value="<?php echo $id; ?>">
											</td>
											<td><?php echo $class_row['name']; ?></td>
											<td width="40"><a href="edit_time_slot.php<?php echo '?id='.$id; ?>" class="btn btn-success"><i class="icon-pencil icon-large"></i> </a></td>
                                     
                               
										</tr>
										<?php } ?>
                               
                               
										</tbody>
									</table>
									</form>
                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>


                </div>
            </div>
		<?php include('footer.php'); ?>
        </div>
		<?php include('script.php'); ?>
    </body>

</html>   <?php
                    include ('dbcon.php');
if (isset($_POST['save'])){
$class_name = $_POST['time_slot_name'];


$query = mysqli_query($con,"select * from time_slot where name  =  '$class_name' ");
$count = mysqli_num_rows($query);

if ($count > 0){ ?>
<script>
alert('time_slot Already Exist');
</script>
<?php
}else{
mysqli_query($con,"insert into time_slot (name) values('$class_name')");
?>
<script>
window.location = "time_slot.php";
</script>
<?php
}
}
?>