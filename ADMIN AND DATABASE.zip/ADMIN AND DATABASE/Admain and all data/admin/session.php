<?php
 session_start(); 
//Check whether the session variable SESS_MEMBER_ID is present or not
if (!isset($_SESSION['id']) || (trim($_SESSION['id']) == '')) { ?>
<script>
window.location = "index.php";
</script>
<?php
}
		$host = "localhost";
$user = "root";
$password = "";
$db = "electronictutor";

$con = mysqli_connect($host,$user,$password,$db) or die("Could not connect to database");
$session_id=$_SESSION['id'];

$user_query = mysqli_query($con,"select * from users where user_id = '$session_id'")or die(mysql_error());
$user_row = mysqli_fetch_assoc($user_query);
$user_username = $user_row['username'];
?>