<?php
include('dbcon.php');
if (isset($_POST['delete_time_slot'])){
$id=$_POST['selector'];

$N = count($id);
for($i=0; $i < $N; $i++)
{
	$result = mysqli_query($con,"DELETE FROM time_slot where name='$id[$i]'");
}
header("location: time_slot.php");
}
?>