<?php
include('header.php'); 
 include('session.php'); 
   $servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "electronictutor";
		// Create connection
		$conn = mysqli_connect($servername, $username, $password,$dbname);
		if(isset($_POST['gen']))
		{
					$res= mysqli_query($conn, "delete from datesheet");
		$res= mysqli_query($conn, "SELECT class_id, class_name from class");
		$pos=strpos("I love php, I love php too!","pho"); 
		
		while($row=$res->fetch_assoc())
		{
			$dCnt=0;
			$cid=$row['class_id'];
			$res2=mysqli_query($conn, "select subject_title from subject where class_id=$cid");
			while($row2= $res2->fetch_assoc())
			{
				$timestamp = strtotime(' +'.$dCnt.' day');
				$day = date('D', $timestamp);
				$mydate=date('l, F d Y', $timestamp);
				$insertDate = date('d-m-Y',$timestamp);
				if($day=="Sun")
				{
				    $dCnt++;
					$timestamp = strtotime(' +'.$dCnt.' day');
				    $day = date('D', $timestamp);
				    $mydate=date('l, F d Y', $timestamp);
				    $insertDate = date('d-m-Y',$timestamp);
				}
                $dCnt++;
				$cls=$row['class_id'];
				$sbjct=$row2['subject_title'];
				$res3= mysqli_query($conn, "insert into datesheet (class_id,subject,date_time, day, time) values($cls, '$sbjct','$insertDate','$day','9:15 AM')");
			}
		}
		header("datesheet.php");
		}
?>
<head>
	<style>
table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
	</head>
    <body>
	    <div class="container-fluid">
            <div class="row-fluid">
					<?php include('sidebar_datesheet.php'); ?>
                
                <!--/span-->
                <div class="span9" id="content">
								        <div id="block_bg" class="block">
                
								<div class="block-content collapse in">
										<div class="span8">
							<!-- block -->
										<div class="navbar navbar-inner block-header">
											<div class="muted pull-left">DateSheet</div>
										</div>
															<div id='DateSheet'></div>		
										</div>
										
										<div class="span4">
											<form method="POST" action="">
										<button class="btn btn-success" style="margin-top: 15px" id="gen" name="gen">Generate DateSheet</button>								</form>			

										</div>	
										<div>
											<?php
											$res= mysqli_query($conn,"select class_id, class_name from class");
											while($row=$res->fetch_assoc())
											{
												$cid= $row['class_id'];
												$cname=$row['class_name'];
												$res2=mysqli_query($conn, "select * from datesheet where class_id=$cid");
												if($res2->num_rows>0)
												{
													echo "<table>
      <tr>
          <center><th><h1>$cname</h1></th></center>
    </tr>
      
    <tr>
      <th>SUBJECT</th>
      <th>DATE</th>
      <th>DAY</th>
      <th>TIME</th>
     </tr>";
     while($row=$res2->fetch_assoc())
     {
     	$sbjct = $row['subject'];
     	$dt=$row['date_time'];
     	$dy= $row['day'];
     	$tm=$row['time'];
     echo "<tr>
     <td>$sbjct</td>
     <td>$dt</td>
     <td>$dy</td>
     <td>$tm</td>
     </tr>";
     }
echo "</table>";
echo "<br><br><br>";
												}
											}
											?>
										</div>
							<!-- block -->
						
										</div>
                                </div>		
                </div>
            </div>
    
         <?php include('footer.php'); ?>
        </div>
	<?php include('script.php'); ?>
	<?php include('admin_calendar_script.php'); ?>
    </body>

</html>