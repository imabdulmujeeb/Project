<?php include('dbcon.php'); ?>
   <div class="row-fluid">
       <a href="time_slot.php" class="btn btn-info"><i class="icon-plus-sign icon-large"></i> Add time_slot</a>
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Edit time_slot</div>
                            </div>
							<?php
							$query = mysqli_query($con,"select * from time_slot where name = '$get_id'")or die(mysql_error());
							$row = mysqli_fetch_array($query);
							?>
                            <div class="block-content collapse in">
                                <div class="span12">
								<form method="post">
										<div class="control-group">
                                          <div class="controls">
                                            <input name="time_slot_name" value="<?php echo $row['name']; ?>" class="input focused" id="focusedInput" type="text" placeholder = "time_slot Name" required>
                                          </div>
                                        </div>
										
									
											<div class="control-group">
                                          <div class="controls">
												<button name="update" class="btn btn-success"><i class="icon-save icon-large"></i></button>

                                          </div>
                                        </div>
                                </form>
								</div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                    <?php
if (isset($_POST['update'])){
$class_name = $_POST['time_slot_name'];
$query = mysqli_query($con,"select * from time_slot where name  =  '$class_name' ")or die(mysql_error());
$count = mysqli_num_rows($query);

if ($count > 0)
{
	echo "<script>alert('time_slot Already Exist')</script>";
}
else	
{
	mysqli_query($con,"update time_slot set name = '$class_name' where name = '$get_id' ")or die(mysql_error());
	echo "<script>window.location = 'time_slot.php'</script>";
}
}
?>