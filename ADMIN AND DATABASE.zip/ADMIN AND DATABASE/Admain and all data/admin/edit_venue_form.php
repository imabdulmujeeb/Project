<?php include('dbcon.php'); ?>
   <div class="row-fluid">
       <a href="venue.php" class="btn btn-info"><i class="icon-plus-sign icon-large"></i> Add Venue</a>
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Edit Venue</div>
                            </div>
							<?php
							$query = mysqli_query($con,"select * from venue where name = '$get_id'")or die(mysql_error());
							$row = mysqli_fetch_array($query);
							?>
                            <div class="block-content collapse in">
                                <div class="span12">
								<form method="post">
										<div class="control-group">
                                          <div class="controls">
                                            <input name="venue_name" value="<?php echo $row['name']; ?>" class="input focused" id="focusedInput" type="text" placeholder = "Venue Name" required>
                                          </div>
                                        </div>
										
									
											<div class="control-group">
                                          <div class="controls">
												<button name="update" class="btn btn-success"><i class="icon-save icon-large"></i></button>

                                          </div>
                                        </div>
                                </form>
								</div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                    <?php
if (isset($_POST['update'])){
$class_name = $_POST['venue_name'];
$query = mysqli_query($con,"select * from venue where name  =  '$class_name' ")or die(mysql_error());
$count = mysqli_num_rows($query);

if ($count > 0)
{
	echo "<script>alert('Venue Already Exist')</script>";
}
else	
{
	mysqli_query($con,"update venue set name = '$class_name' where name = '$get_id' ")or die(mysql_error());
	echo "<script>window.location = 'venue.php'</script>";
}
}
?>