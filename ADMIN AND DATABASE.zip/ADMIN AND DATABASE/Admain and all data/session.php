<?php
//Start session
session_start();
//Check whether the session variable SESS_MEMBER_ID is present or not
if (!isset($_SESSION['id']) || ($_SESSION['id'] == '')) {
    header("location: index.php");
    exit();
}
if (!isset($_SESSION['username']) || ($_SESSION['username'] == '')) {
    $session_id=$_SESSION['id'];
}
else
{
	$session_id=$_SESSION['id'];
$username=$_SESSION['username'];

}
?>