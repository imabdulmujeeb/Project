/*
SQLyog Ultimate v12.09 (64 bit)
MySQL - 10.1.38-MariaDB : Database - electronictutor
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`electronictutor` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `electronictutor`;

/*Table structure for table `activity_log` */

DROP TABLE IF EXISTS `activity_log`;

CREATE TABLE `activity_log` (
  `activity_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `action` varchar(100) NOT NULL,
  PRIMARY KEY (`activity_log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

/*Data for the table `activity_log` */

insert  into `activity_log`(`activity_log_id`,`username`,`date`,`action`) values (1,'jkev','2013-11-18 15:25:33','Add Subject RIZAL'),(2,'jkev','2013-11-18 15:27:08','Edit Subject RIZAL'),(3,'','2013-11-18 15:30:46','Edit Subject IS 221'),(4,'','2013-11-18 15:31:12','Edit Subject IS 222'),(5,'','2013-11-18 15:31:24','Edit Subject IS 223'),(6,'','2013-11-18 15:31:34','Edit Subject IS 224'),(7,'','2013-11-18 15:31:54','Edit Subject IS 227'),(8,'','2013-11-18 15:32:37','Add Subject IS 411B'),(9,'','2013-11-18 15:34:54','Edit User jkev'),(10,'jkev','2014-01-17 13:26:18','Add User admin'),(11,'admin','2017-05-25 05:45:33','Edit Subject SS POL GOV'),(12,'admin','2017-05-25 05:47:15','Edit Subject LIT 1'),(13,'admin','2017-05-25 05:53:59','Edit Subject GNS 201'),(14,'admin','2017-05-25 05:54:27','Edit Subject GNS 222'),(15,'admin','2017-05-25 05:55:34','Edit User teph'),(16,'admin','2017-05-25 05:56:05','Edit User jkev'),(17,'','2018-07-23 21:59:21','Edit Subject IS 411A'),(18,'admin','2018-07-24 15:56:55','Add School Year 2017-2018'),(19,'admin','2018-07-30 22:33:04','Add Subject ITC 1'),(20,'admin','2019-05-07 21:00:45','Add Subject Eng-1'),(21,'admin','2019-05-07 21:01:07','Add Subject Urdu-1'),(22,'admin','2019-05-07 21:01:21','Add Subject Math-1'),(23,'admin','2019-05-07 21:01:32','Add Subject Science-1');

/*Table structure for table `answer` */

DROP TABLE IF EXISTS `answer`;

CREATE TABLE `answer` (
  `answer_id` int(11) NOT NULL AUTO_INCREMENT,
  `quiz_question_id` int(11) NOT NULL,
  `answer_text` varchar(100) NOT NULL,
  `choices` varchar(3) NOT NULL,
  PRIMARY KEY (`answer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=latin1;

/*Data for the table `answer` */

insert  into `answer`(`answer_id`,`quiz_question_id`,`answer_text`,`choices`) values (81,32,'john','A'),(82,32,'smith','B'),(83,32,'kevin','C'),(84,32,'lorayna','D'),(85,34,'Peso','A'),(86,34,'PHP Hypertext','B'),(87,34,'PHP Hypertext Preprosesor','C'),(88,34,'Philippines','D');

/*Table structure for table `assignment` */

DROP TABLE IF EXISTS `assignment`;

CREATE TABLE `assignment` (
  `assignment_id` int(11) NOT NULL AUTO_INCREMENT,
  `floc` varchar(300) NOT NULL,
  `fdatein` varchar(100) NOT NULL,
  `fdesc` varchar(100) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  PRIMARY KEY (`assignment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

/*Data for the table `assignment` */

insert  into `assignment`(`assignment_id`,`floc`,`fdatein`,`fdesc`,`teacher_id`,`class_id`,`fname`) values (2,'uploads/6843_File_Doc3.docx','2013-10-11 01:24:32','fasfasf',13,36,'Assignment number 1'),(3,'uploads/3617_File_login.mdb','2013-10-28 19:35:28','q',9,80,'q'),(4,'admin/uploads/7146_File_normalization.ppt','2013-10-30 18:48:15','fsaf',9,95,'fsaf'),(5,'admin/uploads/7784_File_ABSTRACT.docx','2013-10-30 18:48:33','fsaf',9,95,'dsaf'),(6,'admin/uploads/4536_File_ABSTRACT.docx','2013-10-30 18:53:32','file',9,95,'abstract'),(10,'admin/uploads/2209_File_598378_543547629007198_436971088_n.jpg','2013-11-01 13:13:18','fsafasf',9,95,'Assignment#2'),(11,'admin/uploads/1511_File_bootstrap.css','2013-11-01 13:18:25','sdsa',9,95,'css'),(12,'admin/uploads/4309_File_new  2.txt','2013-11-17 23:21:46','test',12,145,'test'),(13,'admin/uploads/5901_File_IS 112-Personal Productivity Using IS.doc','2013-11-18 16:59:35','q',12,145,'q'),(15,'admin/uploads/7077_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-11-25 10:38:45','afs',18,159,'dasf'),(16,'admin/uploads/8470_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-11-25 10:39:19','test',18,160,'assign1'),(17,'admin/uploads/2840_File_IMG_0698.jpg','2013-11-25 15:53:20','q',12,161,'q'),(19,'','2013-12-07 20:11:39','kevin test',12,162,''),(20,'','2013-12-07 20:26:43','dasddsd',12,145,''),(21,'','2013-12-07 20:26:43','dasddsd',12,162,''),(22,'','2013-12-07 20:27:18','dasffsafsaf',12,162,''),(23,'','2013-12-07 20:33:11','test',12,162,''),(24,'admin/uploads/7053_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-12-07 20:39:05','kevin',12,0,'kevin'),(25,'admin/uploads/2417_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-12-07 20:41:10','kevin',12,0,'kevin'),(26,'admin/uploads/8095_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-12-07 20:43:25','kevin',12,0,'kevin'),(27,'admin/uploads/4089_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-12-07 20:47:48','fasfafaf',12,0,'fasf'),(28,'admin/uploads/2948_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-12-07 20:48:59','dasdasd',12,0,'dasd'),(29,'admin/uploads/5971_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-12-07 20:50:47','dasdasd',12,0,'dsad'),(30,'admin/uploads/6926_File_Resume.docx','2014-02-13 11:27:59','q',12,167,'q');

/*Table structure for table `class` */

DROP TABLE IF EXISTS `class`;

CREATE TABLE `class` (
  `class_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_name` varchar(100) NOT NULL,
  PRIMARY KEY (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

/*Data for the table `class` */

insert  into `class`(`class_id`,`class_name`) values (7,'CS-4A'),(8,'CS-4B'),(13,'CS-3B'),(14,'CS-3C'),(15,'CS-2A'),(16,'CS-2B'),(17,'CS-2C'),(18,'CS-1A'),(19,'CS-1B'),(20,'CS-1C'),(21,'Maths-1A'),(22,'AR-1C'),(23,'Stat-2B'),(24,'CS-B'),(25,'NES 1'),(26,'FSC Pre Engg'),(27,'MPI');

/*Table structure for table `class_quiz` */

DROP TABLE IF EXISTS `class_quiz`;

CREATE TABLE `class_quiz` (
  `class_quiz_id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_class_id` int(11) NOT NULL,
  `quiz_time` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  PRIMARY KEY (`class_quiz_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

/*Data for the table `class_quiz` */

insert  into `class_quiz`(`class_quiz_id`,`teacher_class_id`,`quiz_time`,`quiz_id`) values (13,167,3600,3),(14,167,3600,3),(15,167,1800,3),(16,185,900,0);

/*Table structure for table `class_subject_overview` */

DROP TABLE IF EXISTS `class_subject_overview`;

CREATE TABLE `class_subject_overview` (
  `class_subject_overview_id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_class_id` int(11) NOT NULL,
  `content` varchar(10000) NOT NULL,
  PRIMARY KEY (`class_subject_overview_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `class_subject_overview` */

insert  into `class_subject_overview`(`class_subject_overview_id`,`teacher_class_id`,`content`) values (1,167,'<p>Chapter&nbsp; 1</p>\r\n\r\n<p>Cha</p>\r\n'),(2,189,'<p>Hello Student , This Coruse is About to test the Student Programming Skills Imporvement and Analysis.</p>\r\n\r\n<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n<p style=\"text-align:center\"><u><span style=\"font-size:36px\"><strong>ITC</strong></span></u></p>\r\n\r\n<p><span style=\"font-size:18px\"><strong><u>Topic :</u></strong></span></p>\r\n\r\n<ol>\r\n	<li>For Loop&nbsp;</li>\r\n	<li>If Else</li>\r\n	<li>Conditionals Statements</li>\r\n	<li>Recursion</li>\r\n	<li>Dry Run</li>\r\n	<li>Test Cases</li>\r\n</ol>\r\n\r\n<p>&nbsp;</p>\r\n'),(3,190,'<p>dasdadadadadadad</p>\r\n');

/*Table structure for table `content` */

DROP TABLE IF EXISTS `content`;

CREATE TABLE `content` (
  `content_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `content` mediumtext NOT NULL,
  PRIMARY KEY (`content_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

/*Data for the table `content` */

insert  into `content`(`content_id`,`title`,`content`) values (1,'Mission','<pre>\r\n<span style=\"font-size:16px\"><strong>Mission</strong></span></pre>\r\n\r\n<p style=\"text-align:left\"><span style=\"font-family:arial,helvetica,sans-serif; font-size:medium\"><span style=\"font-size:large\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span></span>&nbsp; &nbsp;<span style=\"font-size:18px\"> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; “To provide a conducive environment for teaching, learning, research and development, where staff and students will interact and compete effectively with other counterparts globally”..&nbsp;</span></p>\r\n\r\n<p style=\"text-align:left\">&nbsp;</p>\r\n'),(2,'Vision','<pre><span style=\"font-size: large;\"><strong>Vision</strong></span></pre>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style=\"font-size: large;\">&nbsp; To be a top class institution for the pursuit of excellence in knowledge , character and service to humanity.. </span><br /><br /></p>'),(3,'History','<pre><span style=\"font-size: large;\">HISTORY &nbsp;</span> </pre>\r\n<p style=\"text-align: justify;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Founded in 1962, the University of Lagos has, for over 5 decades, provided qualitative and research-oriented education to Nigerians and all those who have entered its domain in search of knowledge. At its inception, the University of Lagos was empowered to produce a professional workforce that would steer the political, social and economic development of a newly independent country. Over the last fifty years the University has pursued this mission with vigour, excellence and panache. The University has built a legacy of academic excellence and is now acclaimed publicly as “the University of First Choice and the Nation’s Pride.” The establishment of the University of Lagos in 1962 was informed by the need to intensify the training of a professional workforce for a newly independent Nigeria in search of rapid industrialisation and economic development. It was however quite evident that the country lacked the requisite workforce to actualise the people’s dream. There was a big gulf to be filled, and that required establishing many more universities.</p>'),(5,'Upcoming Events','<pre>\r\nUP COMING EVENTS</pre>\r\n\r\n<p><strong>&gt;</strong> EXAM</p>\r\n\r\n<p><strong>&gt;</strong> INTERCAMPUS MEET</p>\r\n\r\n<p><strong>&gt;</strong> DEFENSE</p>\r\n\r\n<p><strong>&gt;</strong> ENROLLMENT</p>\r\n\r\n<p>&nbsp;</p>\r\n'),(6,'Title','<p><span style=\"font-family:trebuchet ms,geneva\">Electronic Tutor Learning System</span></p>\r\n'),(7,'News','<pre>\r\n<span style=\"font-size:medium\"><em><strong>Recent News\r\n</strong></em></span></pre>\r\n\r\n<h2><span style=\"font-size:small\">Extension and Community Services</span></h2>\r\n\r\n<p style=\"text-align:justify\">The Registry of the University is vested with the responsibility of coordinating various departments/units of the University to ensure efficiency and optimal performance. </p>\r\n\r\n<p style=\"text-align:justify\">The Registry is headed by the Registrar who is the Chief Administrator of the University and statutorily the Secretary to Council, Senate, Congregation and Convocation.The Registrar reports to the Vice-Chancellor on the day-to-day administration of the University.</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; The Act provided for an eleven-member Provisional Council for the University, a Senate to preside over academic affairs, and a separate Council for the Medical School located at the University Teaching Hospital at Idi-Araba, a few kilometres away from the main (Akoka) campus. This was rather unique for, by authority of the Act, the University consisted of two separate institutions—the main university and an autonomous Medical School. The link between the two institutions was tenuous at best, consisting of reciprocal representation on both Councils and membership in the University Senate by professors in the Medical School..</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;The University began with three faculties: Commerce and Business Administration, Law and Medicine. At its first meeting the Board of the Faculty of Commerce and Business Administration changed the name to the Faculty of Business and Social Studies. The faculties of Arts, Education, Engineering and Science were added in 1964..</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\">For the first academic session, 1962/1963, the University admitted 46 students for the Faculty of Commerce and Business Administration and 26 for the Faculty of Law. These students received their first lectures on 22 October 1962 at the temporary site in a secondary school at Idi-Araba, adjacent to the Medical School and the Teaching Hospital. 28 medical students had already commenced lectures three weeks earlier on 3 October, 1962. The University moved from its temporary location in Idi-Araba to the Akoka main campus in September 1965. The direction of the University’s future development was consolidated with the promulgation of the University of Lagos Decree in 1967 (Decree No. 3 of 1967). The new constitution created an integrated and more structurally coherent institution by establishing a single Council for the whole university. The previous arrangement had two separate Councils, one for the University and the other for the Medical School.</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;With the new Act the Medical School ceased to exist as a separate institution and became an integral part of the University of Lagos subject to the full authority of Senate. However, to ensure a measure of autonomy necessary for the smooth discharge of the responsibilities of some specialised units the university adopted the collegiate system under which the Medical School now became the College of Medicine of the University of Lagos. The Faculty of Business and Social Studies was divided into the School of Administration and the School of Social Studies. The Federal Advanced Teachers’ College was integrated into the university as the College of Education. The Institute of Computer Sciences and the Institute of Mass Communication were founded in 1967 and became teaching units a year later. The Institute of Child Health joined the University in 1969</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; The School of Postgraduate Studies, whose dramatic growth has attracted the sobriquet, “the Lagoon Lighthouse, was established on 22 July 1981. In 1984, Federal University of Technology, Abeokuta (FUTAB) was merged with the University of Lagos..</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n'),(10,'Calendar','<pre style=\"text-align:center\">\r\n<span style=\"font-size:medium\"><strong>&nbsp;CALENDAR OF EVENT</strong></span></pre>\r\n\r\n<table align=\"center\" cellpadding=\"0\" cellspacing=\"0\" style=\"line-height:1.6em; margin-left:auto; margin-right:auto\">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n			<p>First Semester &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p>\r\n			</td>\r\n			<td>\r\n			<p>June 10, 2018 to October 11, 2018</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Semestral Break</p>\r\n			</td>\r\n			<td>\r\n			<p>Oct. 12, 2018 to November 3, 2018</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Second Semester</p>\r\n			</td>\r\n			<td>\r\n			<p>Nov. 5, 2017 to March 27, 2018</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Summer Break</p>\r\n			</td>\r\n			<td>\r\n			<p>March 27, 2018 to April 8, 2018</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Summer</p>\r\n			</td>\r\n			<td>\r\n			<p>April 8 , 2018 to May 24, 2018</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n<table cellpadding=\"0\" cellspacing=\"0\" style=\"line-height:1.6em; margin-left:auto; margin-right:auto\">\r\n	<tbody>\r\n		<tr>\r\n			<td colspan=\"4\">\r\n			<p><strong>June 5, 2017 to October 11, 2018 &ndash; First Semester AY 2017-2018</strong></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>June 4, 2018&nbsp; &nbsp; &nbsp;&nbsp;</p>\r\n			</td>\r\n			<td>\r\n			<p>Orientation with the Parents of the College&nbsp;Freshmen</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>June 5</p>\r\n			</td>\r\n			<td>\r\n			<p>First Day of Service</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>June 5</p>\r\n			</td>\r\n			<td>\r\n			<p>College Personnel General Assembly</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>June 6,7</p>\r\n			</td>\r\n			<td>\r\n			<p>In-Service Training (Departmental)</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>June 10</p>\r\n			</td>\r\n			<td>\r\n			<p>First Day of Classes</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>June 14</p>\r\n			</td>\r\n			<td>\r\n			<p>Orientation with Students by College/Campus/Department</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>June 19,20,21</p>\r\n			</td>\r\n			<td>\r\n			<p>Branch/Campus Visit for Administrative / Academic/Accreditation/ Concerns</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td rowspan=\"2\">\r\n			<p>June</p>\r\n			</td>\r\n			<td>\r\n			<p>Club Organizations (By Discipline/Programs)</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Student Affiliation/Induction Programs</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>July</p>\r\n			</td>\r\n			<td>\r\n			<p>Nutrition Month (Sponsor: Laboratory School)</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>July 11, 12</p>\r\n			</td>\r\n			<td>\r\n			<p>Long Tests</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>August&nbsp; 8, 9</p>\r\n			</td>\r\n			<td>\r\n			<p>Midterm Examinations</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>August 19</p>\r\n			</td>\r\n			<td>\r\n			<p>ArawngLahi</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>August 23</p>\r\n			</td>\r\n			<td>\r\n			<p>Submission of Grade Sheets for Midterm</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>August</p>\r\n			</td>\r\n			<td>\r\n			<p>Recognition Program (Dean&rsquo;s List)</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>August 26</p>\r\n			</td>\r\n			<td>\r\n			<p>National Heroes Day (Regular Holiday)</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>August 28, 29, 30</p>\r\n			</td>\r\n			<td>\r\n			<p>Sports and Cultural Meet</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>September 19,20</p>\r\n			</td>\r\n			<td>\r\n			<p>Long Tests</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>October 5</p>\r\n			</td>\r\n			<td>\r\n			<p>Teachers&rsquo; Day / World Teachers&rsquo; Day</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>October 10, 11</p>\r\n			</td>\r\n			<td>\r\n			<p>Final Examination</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>October 12</p>\r\n			</td>\r\n			<td>\r\n			<p>Semestral Break</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n<table cellpadding=\"0\" cellspacing=\"0\" style=\"margin-left:auto; margin-right:auto\">\r\n	<tbody>\r\n		<tr>\r\n			<td colspan=\"4\">\r\n			<p><strong>Nov. 4, 2016 to March 27, 2017 &ndash; Second Semester AY 2016-2017</strong></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>November 4 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p>\r\n			</td>\r\n			<td>\r\n			<p>Start of Classes</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>November 19, 20, 21, 22</p>\r\n			</td>\r\n			<td>\r\n			<p>Intercampus Sports and Cultural Fest/College Week</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>December 5, 6</p>\r\n			</td>\r\n			<td>\r\n			<p>Long Tests</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>December 19,20</p>\r\n			</td>\r\n			<td>\r\n			<p>Thanksgiving Celebrations</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>December 21</p>\r\n			</td>\r\n			<td>\r\n			<p>Start of Christmas Vacation</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>December 25</p>\r\n			</td>\r\n			<td>\r\n			<p>Christmas Day (Regular Holiday)</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>December 30</p>\r\n			</td>\r\n			<td>\r\n			<p>Rizal Day (Regular Holiday)</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>January 6, 2017</p>\r\n			</td>\r\n			<td>\r\n			<p>Classes Resume</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>January 9, 10</p>\r\n			</td>\r\n			<td>\r\n			<p>Midterm Examinations</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>January 29</p>\r\n			</td>\r\n			<td>\r\n			<p>Submission of Grades Sheets for Midterm</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>February 13, 14</p>\r\n			</td>\r\n			<td>\r\n			<p>Long Tests</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>March 6, 7</p>\r\n			</td>\r\n			<td>\r\n			<p>Final Examinations (Graduating)</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>March 13, 14</p>\r\n			</td>\r\n			<td>\r\n			<p>Final Examinations (Non-Graduating)</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>March 17, 18, 19, 20, 21</p>\r\n			</td>\r\n			<td>\r\n			<p>Graduation Ceremony</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>March 27</p>\r\n			</td>\r\n			<td>\r\n			<p>Post UTME</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>June 5, 2017</p>\r\n			</td>\r\n			<td>\r\n			<p>Matriculation</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n<table border=\"1\" cellpadding=\"0\" cellspacing=\"0\" style=\"margin-left:auto; margin-right:auto\">\r\n	<tbody>\r\n		<tr>\r\n			<td colspan=\"2\">\r\n			<p><strong>CONVOCATION</strong></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>MONTHS &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</p>\r\n			</td>\r\n			<td>\r\n			<p>UNIT-IN-CHARGE</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>June, Sept. and Dec. 2017, March 2017</p>\r\n			</td>\r\n			<td>\r\n			<p>COE</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>July and October 2017, Jan. 2017</p>\r\n			</td>\r\n			<td>\r\n			<p>SAS</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>August and November 2017, Feb. 2017</p>\r\n\r\n			<p>April and May 2017</p>\r\n			</td>\r\n			<td>\r\n			<p>CIT</p>\r\n\r\n			<p>GASS</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n'),(11,'Directories','<div class=\"jsn-article-content\" style=\"text-align: left;\">\r\n<pre>\r\n<span style=\"font-size:medium\"><em><strong>DIRECTORIES</strong></em></span></pre>\r\n\r\n<ul>\r\n	<li>Lab School - 080712-0848</li>\r\n	<li>Accounting - 080495-5560</li>\r\n	<li>VC Office - 08098987876</li>\r\n	<li>Library - 080495-1635</li>\r\n	<li>Registrar Office - 080495-4657</li>\r\n	<li>Cashier - 080712-7272</li>\r\n	<li>ICT - 080712-0670</li>\r\n	<li>Hostel - 080495-6017</li>\r\n	\r\n	<li>Internet Lab - 080712-6144/712-6459</li>\r\n	<li>COA - 080495-5748</li>\r\n	<li>Busary- 080476-1600</li>\r\n	<li>HRM - 090495-4996</li>\r\n	<li>Extension - 090457-2819</li>\r\n	<li>Research - 090712-8464</li>\r\n	\r\n</ul>\r\n</div>\r\n'),(12,'president','<p>It is my great pleasure and privilege to welcome you to Unilag&rsquo;s official website. Accept my deep appreciation for continuously taking interest in Unilag and its programs and activities.<br /> Recently, the challenges of the knowledge era of the 21st Century led me to think very deeply how educational institutions of higher learning must vigorously pursue relevant e<img style=\"float: left;\" src=\"images/president.jpg\" alt=\"\" />ducation to compete with and respond to the challenges of globalization. As an international fellow, I realized that in the face of this globalization and technological advancement, educational institutions are compelled to work extraordinary in educating the youths and enhancing their potentials for gainful employment and realization of their dreams to become effective citizens.<br /><br /> Honored and humbled to be given the opportunity for stewardship of this good College, I am fully aware that the goal is to make Unilag as the center of excellence or development in various fields. The vision, Unilag ExCELS: Excellence, Competence and Educational Leadership in Science and Technology is a profound battle cry for each member of Unilag Community. A Unilag student must be technologically and academically competent, socially mature, safety conscious with care for the environment, a good citizen and possesses high moral values. The way the University is being managed, the internal and the external culture of all stockholders, and the efforts for quality and excellence will result to the establishment of the good corporate image of the University. The hallmark is reflected as the image of the good institution.<br /><br /> The tasks at hand call for our full cooperation, support and active participation. Therefore, I urge everyone to help me in the crusade to <br /><br /></p>\r\n<p style=\"text-align: justify;\"><span style=\"line-height: 1.3em;\">Provide wider access to CHMSC programs;</span></p>\r\n<p style=\"text-align: justify;\"><span style=\"line-height: 1.3em;\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;* Harness the potentials of students thru effective teaching and learning methodologies and techniques;</span></p>\r\n<p style=\"text-align: justify;\"><span style=\"line-height: 1.3em;\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;* Enable Unilag Environment for All through secure green campus;</span></p>\r\n<p style=\"text-align: justify;\"><span style=\"line-height: 1.3em;\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;* Advocate green movement, protect intellectual property and stimulate innovation;</span></p>\r\n<p style=\"text-align: justify;\"><span style=\"line-height: 1.3em;\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;* Promote lifelong learning;</span></p>\r\n<p style=\"text-align: justify;\"><span style=\"line-height: 1.3em;\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;* Conduct Research and Development for community and poverty alleviation;</span></p>\r\n<p style=\"text-align: justify;\"><span style=\"line-height: 1.3em;\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;* Share and disseminate knowledge through publication and extension outreach to communities; and</span></p>\r\n<p style=\"text-align: justify;\"><span style=\"line-height: 1.3em;\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;*Strengthen Institute-industry linkages and public-private partnership for mutual interest.</span></p>\r\n<p style=\"text-align: justify;\"><br /><span style=\"line-height: 1.3em; text-align: justify;\">Together, WE can make CHMSC</span></p>\r\n<p style=\"text-align: justify;\"><br /><span style=\"line-height: 1.3em;\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;*A model green institution for Human Resources Development, a builder of human resources in the knowledge era of the 21st Century;</span></p>\r\n<p style=\"text-align: justify;\"><span style=\"line-height: 1.3em;\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; *A center for curricular innovations and research especially in education, technology, engineering, ICT and entrepreneurship; and</span></p>\r\n<p style=\"text-align: justify;\"><span style=\"line-height: 1.3em;\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; *A Provider of quality graduates in professional and technological programs for industry and community.</span></p>\r\n<p style=\"text-align: justify;\"><br /><br /> Dear readers and guests, these are the challenges for every CHMSCian to hurdle and the dreams to realize. This website will be one of the connections with you as we ardently take each step. Feel free to visit often and be kept posted as we continue to work for discoveries and advancement that will bring benefits to the lives of the students, the community, and the world, as a whole.<br /><br /> Warmest welcome and I wish you well!</p>\r\n<p style=\"text-align: justify;\"><br /><br /></p>\r\n<p style=\"text-align: justify;\">RENATO M. SOROLLA, Ph.D.<br />SUC President II</p>'),(13,'motto','<p><strong><span style=\"color:#FFF0F5\"><span style=\"font-family:arial,helvetica,sans-serif\">CHMSC EXCELS:</span></span></strong></p>\r\n\r\n<p><strong><span style=\"color:#FFF0F5\"><span style=\"font-family:arial,helvetica,sans-serif\">Excellence, Competence and Educational</span></span></strong></p>\r\n\r\n<p><strong><span style=\"color:#FFF0F5\"><span style=\"font-family:arial,helvetica,sans-serif\">Leadership in Science and Technology</span></span></strong></p>\r\n'),(14,'Campuses','<pre>\r\n<span style=\"font-size:16px\"><strong>Campuses</strong></span></pre>\r\n\r\n<ul>\r\n	<li>Ikeja Campus</li>\r\n	<li>Festac Campus</li>\r\n	<li>Ikoyi Campus</li>\r\n	<li>Surulere Campus<br />\r\n	&nbsp;</li>\r\n</ul>\r\n');

/*Table structure for table `datesheet` */

DROP TABLE IF EXISTS `datesheet`;

CREATE TABLE `datesheet` (
  `recordId` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) DEFAULT NULL,
  `subject_id` int(10) NOT NULL,
  `subject` varchar(50) DEFAULT NULL,
  `date_time` varchar(15) DEFAULT NULL,
  `time` varchar(10) DEFAULT NULL,
  `venue` varchar(10) NOT NULL,
  `invigilator` varchar(30) NOT NULL,
  `invigilator_id` int(10) NOT NULL,
  PRIMARY KEY (`recordId`)
) ENGINE=InnoDB AUTO_INCREMENT=1703 DEFAULT CHARSET=latin1;

/*Data for the table `datesheet` */

insert  into `datesheet`(`recordId`,`class_id`,`subject_id`,`subject`,`date_time`,`time`,`venue`,`invigilator`,`invigilator_id`) values (1679,7,37,'Law on Obligation and Contracts','2019-05-18','5:30 PM','Hall 4','Ahmed Tunde-4',11),(1680,7,38,'Social Philosophy & Logic','2019-05-18','2:30 PM','Hall 8','Ahmed Tunde-4',11),(1681,7,42,'ITC ','2019-05-19','11:30 AM','Hall 5','Lovelyn  Adesuwa-5',17),(1682,8,39,'Quantitative Techniques in Business','2019-05-19','11:30 AM','Room 2','Aisha Olatubosu-4',14),(1683,8,40,'Current Affairs','2019-05-26','8:30 AM','Hall 8','Ahmad Deola-4',18),(1684,8,41,'Senior Systems Project 2','2019-05-19','7:00 AM','Hall 4','Ahmed Tunde-4',11),(1685,13,14,'Senior Systems Project 1','2019-05-20','8:30 AM','Hall 8','Ahmad Deola-4',18),(1686,13,24,'Business Process','2019-05-26','2:30 PM','Hall 3','Muhammad Ahmad Naeem-9',20),(1687,13,25,'Discrete Structures','2019-05-27','2:30 PM','Hall 7','Ahmad Naeem-10',22),(1688,13,26,'IS Programming 2','2019-05-21','5:30 PM','Hall 5','Lovelyn  Adesuwa-5',17),(1689,13,32,'Structured Query Language','2019-05-26','5:30 PM','Hall 5','Ahmad Deola-4',18),(1690,13,33,'Information System Planning','2019-05-19','2:30 PM','Hall 7','Ayo Tunde-4',5),(1691,13,36,'System Analysis and Design','2019-05-21','2:30 PM','Hall 1','Jerry Philip-4',9),(1692,14,15,'Effective Human Communication for IT Professional','2019-05-20','8:30 PM','Hall 5','Ahmed Tunde-4',11),(1693,14,17,'Introduction to the IM Professional and Ethics','2019-05-20','8:30 PM','Hall 7','Ahmad Naeem-10',22),(1694,14,28,'English  Literature','2019-05-19','5:30 PM','Room 2','Funmi Adeleke-4',12),(1695,14,29,'Fundamentals of Accounting 2','2019-05-19','8:30 PM','Hall 7','Jerry Philip-4',9),(1696,14,35,'E-commerce Strategy Architectural','2019-05-20','2:30 PM','Hall 10','Ahmad Naeem-10',22),(1697,15,16,'Programming Languages','2019-05-20','8:30 AM','Hall 9','Aisha Olatubosu-4',14),(1698,15,23,'Network and Internet Technology','2019-05-21','5:30 PM','Hall 4','Jerry Philip-4',9),(1699,15,30,'Team Sports','2019-05-19','5:30 PM','Hall 8','Ahmad Deola-4',18),(1700,15,34,'Management of Technology','2019-05-18','7:00 AM','Hall 7','Ahmad Naeem-10',22),(1701,21,22,'Application Development','2019-05-20','7:00 AM','Room 2','Aisha Olatubosu-4',14),(1702,26,31,'Survey of Programming Languages','2019-05-23','2:30 PM','Hall 6','Funmi Adeleke-4',12);

/*Table structure for table `department` */

DROP TABLE IF EXISTS `department`;

CREATE TABLE `department` (
  `department_id` int(11) NOT NULL AUTO_INCREMENT,
  `department_name` varchar(100) NOT NULL,
  `dean` varchar(100) NOT NULL,
  PRIMARY KEY (`department_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

/*Data for the table `department` */

insert  into `department`(`department_id`,`department_name`,`dean`) values (4,'Faculty of Social Science','Dr. Antonio Deraja'),(5,'Faculty of Arts','DR.'),(9,'Faculty of Science','null'),(10,'Faculty of Computer','Dr. Test');

/*Table structure for table `event` */

DROP TABLE IF EXISTS `event`;

CREATE TABLE `event` (
  `event_id` int(11) NOT NULL AUTO_INCREMENT,
  `event_title` varchar(100) NOT NULL,
  `teacher_class_id` int(11) NOT NULL,
  `date_start` varchar(100) NOT NULL,
  `date_end` varchar(100) NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

/*Data for the table `event` */

insert  into `event`(`event_id`,`event_title`,`teacher_class_id`,`date_start`,`date_end`) values (13,'Start of Classes',0,'11/04/2013','11/04/2013'),(14,'Intercampus Sports and Cultural Fest/College Week',0,'11/19/2013','11/22/2013'),(15,'Long Test',113,'12/05/2013','12/06/2013'),(16,'Long Test',0,'12/05/2013','12/06/2013'),(17,'sdasf',147,'11/16/2013','11/16/2013'),(18,'Orientation',0,'7/30/2018','8/30/2018'),(19,'QUIZ 2',190,'7/30/2018','8/30/2018'),(20,'mdfjff',0,'122','1122');

/*Table structure for table `files` */

DROP TABLE IF EXISTS `files`;

CREATE TABLE `files` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `floc` varchar(500) NOT NULL,
  `fdatein` varchar(200) NOT NULL,
  `fdesc` varchar(100) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `uploaded_by` varchar(100) NOT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=MyISAM AUTO_INCREMENT=140 DEFAULT CHARSET=latin1;

/*Data for the table `files` */

insert  into `files`(`file_id`,`floc`,`fdatein`,`fdesc`,`teacher_id`,`class_id`,`fname`,`uploaded_by`) values (133,'admin/uploads/7939_File_449E26DB.jpg','2014-02-20 10:31:38','sas',14,177,'sss',''),(132,'admin/uploads/7939_File_449E26DB.jpg','2014-02-20 10:29:53','sas',14,178,'sss',''),(131,'admin/uploads/7939_File_449E26DB.jpg','2014-02-20 10:28:09','sas',14,12,'sss',''),(129,'admin/uploads/7939_File_449E26DB.jpg','2014-02-20 10:12:38','sas',0,12,'sss',''),(130,'admin/uploads/7939_File_449E26DB.jpg','2014-02-20 10:26:11','sas',0,12,'sss',''),(128,'admin/uploads/7614_File_1476273_644977475552481_2029187901_n.jpg','2014-02-13 13:31:18','qwwqw',12,185,'kevi','Ruby Maria'),(127,'admin/uploads/1085_File_Resume.docx','2014-02-13 12:53:09','q',12,183,'q','Ruby Maria'),(126,'admin/uploads/7895_File_PERU REPORT.pptx','2014-02-13 12:35:42','chapter 1',12,182,'chapter 1','Ruby Maria'),(125,'admin/uploads/2658_File_kevin.docx','2014-02-13 11:10:56','test',12,181,'test','Ruby Maria'),(123,'admin/uploads/4801_File_painting-02.jpg','2013-12-11 12:02:46','jdkasjfd',12,163,'Test','Ruby Maria'),(122,'admin/uploads/3985_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-12-07 20:00:22','dasdasd',12,145,'dasd','Ruby Maria'),(121,'admin/uploads/7439_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-12-07 19:59:46','asdad',12,162,'kevin','Ruby Maria'),(120,'admin/uploads/7439_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-12-07 19:59:46','asdad',12,145,'kevin','Ruby Maria'),(119,'admin/uploads/3166_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-12-07 19:58:44','kevin',12,145,'kevin','Ruby Maria'),(118,'admin/uploads/4849_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-11-26 23:59:20','q',0,162,'qq','Stephanie'),(117,'admin/uploads/9467_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-11-26 10:42:37','test',0,162,'report group 1','Maria'),(116,'admin/uploads/5990_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-11-26 02:51:24','w',12,162,'w','Ruby Maria'),(115,'admin/uploads/5990_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-11-26 02:51:24','w',12,145,'w','Ruby Maria'),(138,'admin/uploads/3906_File_hydra-7.1-src.tar.gz','2018-07-24 21:20:50','This file for testing the uploading of the matreial',12,189,'TestFile','FunmiAdeleke'),(139,'admin/uploads/5429_File_100RS NOTE PIC.jpg','2018-07-30 23:10:31','ssss',0,190,'Test','AHMADNAEEM');

/*Table structure for table `message` */

DROP TABLE IF EXISTS `message`;

CREATE TABLE `message` (
  `message_id` int(11) NOT NULL AUTO_INCREMENT,
  `reciever_id` int(11) NOT NULL,
  `content` varchar(200) NOT NULL,
  `date_sended` varchar(100) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `reciever_name` varchar(50) NOT NULL,
  `sender_name` varchar(200) NOT NULL,
  `message_status` varchar(100) NOT NULL,
  PRIMARY KEY (`message_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

/*Data for the table `message` */

insert  into `message`(`message_id`,`reciever_id`,`content`,`date_sended`,`sender_id`,`reciever_name`,`sender_name`,`message_status`) values (2,11,'fasf','2013-11-13 13:15:47',42,'Aladin Cabrera','john kevin lorayna',''),(4,71,'bcjhbcjksdbckldj','2013-11-25 15:59:13',71,'Noli Mendoza','Noli Mendoza','read'),(27,93,'fa','2013-12-02 00:01:54',12,'John Kevin  Lorayna','Ruby Mae  Morante',''),(28,136,'Submit your classcard','2014-02-13 13:35:21',12,'Jorgielyn Serfino','Ruby Mae  Morante',''),(29,22,'HELLLO ','2018-07-30 23:07:55',221,'Ahmad Naeem','AHMAD NAEEM','');

/*Table structure for table `message_sent` */

DROP TABLE IF EXISTS `message_sent`;

CREATE TABLE `message_sent` (
  `message_sent_id` int(11) NOT NULL AUTO_INCREMENT,
  `reciever_id` int(11) NOT NULL,
  `content` varchar(200) NOT NULL,
  `date_sended` varchar(100) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `reciever_name` varchar(100) NOT NULL,
  `sender_name` varchar(100) NOT NULL,
  PRIMARY KEY (`message_sent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

/*Data for the table `message_sent` */

insert  into `message_sent`(`message_sent_id`,`reciever_id`,`content`,`date_sended`,`sender_id`,`reciever_name`,`sender_name`) values (1,42,'sad','2013-11-12 22:50:05',42,'john kevin lorayna','john kevin lorayna'),(2,11,'fasf','2013-11-13 13:15:47',42,'Aladin Cabrera','john kevin lorayna'),(3,12,'bjhkcbkjsdnckldvls','2013-11-25 15:58:55',71,'Ruby Mae  Morante','Noli Mendoza'),(4,71,'bcjhbcjksdbckldj','2013-11-25 15:59:13',71,'Noli Mendoza','Noli Mendoza'),(5,12,'test','2013-11-30 20:54:05',93,'Ruby Mae  Morante','John Kevin  Lorayna'),(11,12,'tst','2013-12-01 23:38:40',93,'Ruby Mae  Morante','John Kevin  Lorayna'),(12,12,'fasfasf','2013-12-01 23:49:13',93,'Ruby Mae  Morante','John Kevin  Lorayna'),(13,136,'Submit your classcard','2014-02-13 13:35:21',12,'Jorgielyn Serfino','Ruby Mae  Morante'),(14,22,'HELLLO ','2018-07-30 23:07:55',221,'Ahmad Naeem','AHMAD NAEEM');

/*Table structure for table `notification` */

DROP TABLE IF EXISTS `notification`;

CREATE TABLE `notification` (
  `notification_id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_class_id` int(11) NOT NULL,
  `notification` varchar(100) NOT NULL,
  `date_of_notification` varchar(50) NOT NULL,
  `link` varchar(100) NOT NULL,
  PRIMARY KEY (`notification_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

/*Data for the table `notification` */

insert  into `notification`(`notification_id`,`teacher_class_id`,`notification`,`date_of_notification`,`link`) values (2,0,'Add Downloadable Materials file name <b>sss</b>','2014-01-17 14:35:32','downloadable_student.php'),(3,167,'Add Annoucements','2014-01-17 14:36:32','announcements_student.php'),(4,0,'Add Downloadable Materials file name <b>test</b>','2014-02-13 11:10:56','downloadable_student.php'),(5,167,'Add Assignment file name <b>q</b>','2014-02-13 11:27:59','assignment_student.php'),(6,0,'Add Downloadable Materials file name <b>chapter 1</b>','2014-02-13 12:35:42','downloadable_student.php'),(7,0,'Add Downloadable Materials file name <b>q</b>','2014-02-13 12:53:09','downloadable_student.php'),(8,0,'Add Downloadable Materials file name <b>kevi</b>','2014-02-13 13:31:18','downloadable_student.php'),(9,185,'Add Practice Quiz file','2014-02-13 13:33:27','student_quiz_list.php'),(10,167,'Add Annoucements','2014-02-13 13:45:59','announcements_student.php'),(11,0,'Add Downloadable Materials file name <b>q</b>','2014-02-21 16:43:38','downloadable_student.php'),(12,0,'Add Downloadable Materials file name <b>q</b>','2014-02-21 16:46:18','downloadable_student.php'),(13,0,'Add Downloadable Materials file name <b>q</b>','2014-02-21 16:46:49','downloadable_student.php'),(14,0,'Add Downloadable Materials file name <b>q</b>','2014-02-21 16:52:30','downloadable_student.php'),(15,0,'Add Downloadable Materials file name <b>TestFile</b>','2018-07-24 21:20:50','downloadable_student.php'),(16,189,'Add Annoucements','2018-07-24 21:26:26','announcements_student.php');

/*Table structure for table `notification_read` */

DROP TABLE IF EXISTS `notification_read`;

CREATE TABLE `notification_read` (
  `notification_read_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `student_read` varchar(50) NOT NULL,
  `notification_id` int(11) NOT NULL,
  PRIMARY KEY (`notification_read_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `notification_read` */

insert  into `notification_read`(`notification_read_id`,`student_id`,`student_read`,`notification_id`) values (1,75,'yes',10),(2,75,'yes',5),(3,75,'yes',3);

/*Table structure for table `notification_read_teacher` */

DROP TABLE IF EXISTS `notification_read_teacher`;

CREATE TABLE `notification_read_teacher` (
  `notification_read_teacher_id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` int(11) NOT NULL,
  `student_read` varchar(100) NOT NULL,
  `notification_id` int(11) NOT NULL,
  PRIMARY KEY (`notification_read_teacher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `notification_read_teacher` */

insert  into `notification_read_teacher`(`notification_read_teacher_id`,`teacher_id`,`student_read`,`notification_id`) values (1,12,'yes',14),(2,12,'yes',13),(3,12,'yes',12),(4,12,'yes',11),(5,12,'yes',10),(6,12,'yes',9),(7,12,'yes',8),(8,12,'yes',7);

/*Table structure for table `question_type` */

DROP TABLE IF EXISTS `question_type`;

CREATE TABLE `question_type` (
  `question_type_id` int(11) NOT NULL,
  `question_type` varchar(150) NOT NULL,
  PRIMARY KEY (`question_type_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `question_type` */

insert  into `question_type`(`question_type_id`,`question_type`) values (1,'Multiple Choice'),(2,'True or False');

/*Table structure for table `quiz` */

DROP TABLE IF EXISTS `quiz`;

CREATE TABLE `quiz` (
  `quiz_id` int(11) NOT NULL AUTO_INCREMENT,
  `quiz_title` varchar(50) NOT NULL,
  `quiz_description` varchar(100) NOT NULL,
  `date_added` varchar(100) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  PRIMARY KEY (`quiz_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `quiz` */

insert  into `quiz`(`quiz_id`,`quiz_title`,`quiz_description`,`date_added`,`teacher_id`) values (3,'Sample Test','Test','2013-12-03 23:01:56',12),(4,'Chapter 1','topics','2013-12-13 01:51:02',14),(5,'test3','123','2014-01-16 04:12:07',12);

/*Table structure for table `quiz_question` */

DROP TABLE IF EXISTS `quiz_question`;

CREATE TABLE `quiz_question` (
  `quiz_question_id` int(11) NOT NULL AUTO_INCREMENT,
  `quiz_id` int(11) NOT NULL,
  `question_text` varchar(100) NOT NULL,
  `question_type_id` int(11) NOT NULL,
  `points` int(11) NOT NULL,
  `date_added` varchar(100) NOT NULL,
  `answer` varchar(100) NOT NULL,
  PRIMARY KEY (`quiz_question_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

/*Data for the table `quiz_question` */

insert  into `quiz_question`(`quiz_question_id`,`quiz_id`,`question_text`,`question_type_id`,`points`,`date_added`,`answer`) values (33,5,'<p>q</p>\r\n',2,0,'2014-01-17 04:15:03','False'),(34,3,'<p>Php Stands for ?</p>\r\n',1,0,'2014-01-17 12:25:17','C'),(35,3,'<p>Echo is a Php code that display the output.</p>\r\n',2,0,'2014-01-17 12:26:18','True');

/*Table structure for table `school_year` */

DROP TABLE IF EXISTS `school_year`;

CREATE TABLE `school_year` (
  `school_year_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_year` varchar(100) NOT NULL,
  PRIMARY KEY (`school_year_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `school_year` */

insert  into `school_year`(`school_year_id`,`school_year`) values (3,'2013-2014'),(4,'2017-2018');

/*Table structure for table `student` */

DROP TABLE IF EXISTS `student`;

CREATE TABLE `student` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `class_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`student_id`,`class_id`)
) ENGINE=MyISAM AUTO_INCREMENT=224 DEFAULT CHARSET=latin1;

/*Data for the table `student` */

insert  into `student`(`student_id`,`firstname`,`lastname`,`class_id`,`username`,`password`,`location`,`status`) values (113,'Clifford','Okoro',13,'21100324','','uploads/NO-IMAGE-AVAILABLE.jpg','Unregistered'),(112,'Raymond','Seun',13,'2700372','','uploads/NO-IMAGE-AVAILABLE.jpg','Unregistered'),(111,'Mark ','Dominic',13,'21100867','heni','uploads/mark.jpg','Unregistered'),(108,'Angela','Kalu',13,'21101151','','uploads/dp.jpg','Unregistered'),(105,'Nneka','Amaka',13,'21101131','','uploads/Koala.jpg','Unregistered'),(106,'Raphael','Obi',13,'29000676','','uploads/razel.jpg','Unregistered'),(103,'James','Godwin',13,'21100617','','uploads/NO-IMAGE-AVAILABLE.jpg','Unregistered'),(104,'Felix','Uba',13,'21100277','lms10117','uploads/kirb.jpg','Unregistered'),(100,'Jamilah','Bello',13,'21100303','','uploads/jamila.jpg','Unregistered'),(101,'Jane','Francessa',13,'21100318','sen','uploads/xenia.jpg','Unregistered'),(102,'Chris','Charles',13,'21101124','','uploads/carel.jpg','Unregistered'),(97,'Joy','Adesuwa',13,'20101289','','uploads/Desert.jpg','Unregistered'),(98,'Christine Joy','Madu',13,'21100579','','uploads/tin.jpg','Unregistered'),(95,'Fola','Ade',13,'21101142','','uploads/ergin.jpg','Unregistered'),(93,'John Kevin ','Lola',7,'111','teph','uploads/3094_384893504898082_1563225657_n.jpg','Registered'),(94,'Leah','Padita',13,'21100471','','uploads/NO-IMAGE-AVAILABLE.jpg','Unregistered'),(76,'Jane','Amaka',13,'21100555','123','uploads/maica.jpg','Registered'),(107,'Harry','Bright',13,'29001002','florypis','uploads/harry.jpg','Registered'),(110,'Tunji','Fashola',13,'21100881','','uploads/baby.jpg','Unregistered'),(99,'Temi','Adewale',13,'21100315','','uploads/NO-IMAGE-AVAILABLE.jpg','Unregistered'),(96,'Bolanle','Aisha',13,'20101436','','uploads/NO-IMAGE-AVAILABLE.jpg','Unregistered'),(209,'daniel','harry',20,'21300311','','uploads/NO-IMAGE-AVAILABLE.jpg','Unregistered'),(75,'Ayo','Kunle',13,'21100855','em','uploads/em2.jpg','Unregistered'),(74,'Musa','Ibrahim',13,'21100913','','uploads/nonie.jpg','Unregistered'),(73,'Stephanie','Joyce',13,'21101042','tephai','uploads/3094_384893504898082_1563225657_n.jpg','Registered'),(72,'Jerry','Biodun',13,'21100547','test','uploads/von.jpg','Unregistered'),(71,'Nuhu','Ali',13,'21100556','noledel','uploads/noli.jpg','Registered'),(134,'Victor Anthony','Jacob',12,'21101050','akositon','uploads/win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','Registered'),(135,'Albert ','Kelechi',14,'20101361','','uploads/NO-IMAGE-AVAILABLE.jpg','Unregistered'),(136,'Olamide','Segun',7,'20100331','jorgie','uploads/Koala.jpg','Registered'),(141,'James','Wisdom',15,'21100695','iloveyoujam','uploads/1463666_678111108874417_1795412912_n.jpg','Registered'),(147,'Jerry','Okoro',12,'21100369','jerwin27 cute','uploads/NO-IMAGE-AVAILABLE.jpg','Registered'),(157,'Olamide','Francis',12,'21100393','DianaraSayon','uploads/NO-IMAGE-AVAILABLE.jpg','Registered'),(162,'keisha','Adesuwa',14,'21101182','kimzteng','uploads/29001002.jpg','Registered'),(210,'charles','Obi',20,'21300036','sawsa','uploads/NO-IMAGE-AVAILABLE.jpg','Registered'),(179,'Maryjane','Nwafor',14,'21100710','test','uploads/win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','Registered'),(208,'Adeyinka','Bello',19,'21300413','olebirish','uploads/Desert.jpg','Registered'),(212,'Maria','Vincent',15,'21200363','chrys','uploads/380903_288008981235527_682004916_n.jpg','Registered'),(214,'Maria','Ojo',18,'21300375','maayeeh','uploads/NO-IMAGE-AVAILABLE.jpg','Registered'),(219,'Ahmed','Tunde',18,'2018321','ahmed','uploads/VICTOR CHUTTE.jpg','Registered'),(218,'josie','banday',7,'20100452','heaven','uploads/NO-IMAGE-AVAILABLE.jpg','Registered'),(220,'Muhammad Ahmad','Naeem',22,'2367','dj123','uploads/NO-IMAGE-AVAILABLE.jpg','Registered'),(221,'AHMAD','NAEEM',25,'2000123','test','uploads/NO-IMAGE-AVAILABLE.jpg','Registered'),(218,'josie','banday',13,'20100452','heaven','uploads/NO-IMAGE-AVAILABLE.jpg','Registered'),(223,'Abubakar','Shoaib',26,'2010','12345','uploads/NO-IMAGE-AVAILABLE.jpg','Registered');

/*Table structure for table `student_assignment` */

DROP TABLE IF EXISTS `student_assignment`;

CREATE TABLE `student_assignment` (
  `student_assignment_id` int(11) NOT NULL AUTO_INCREMENT,
  `assignment_id` int(11) NOT NULL,
  `floc` varchar(100) NOT NULL,
  `assignment_fdatein` varchar(50) NOT NULL,
  `fdesc` varchar(100) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `student_id` int(11) NOT NULL,
  `grade` varchar(5) NOT NULL,
  PRIMARY KEY (`student_assignment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

/*Data for the table `student_assignment` */

insert  into `student_assignment`(`student_assignment_id`,`assignment_id`,`floc`,`assignment_fdatein`,`fdesc`,`fname`,`student_id`,`grade`) values (21,13,'admin/uploads/1414_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-11-24 11:59:28','fasfasfasfsfsafasf','safas',93,''),(22,13,'admin/uploads/5554_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-11-24 12:07:46','fasfaf','fdasf',93,''),(23,13,'admin/uploads/3202_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-11-24 12:08:21','fasf','fasf',93,''),(24,13,'admin/uploads/6535_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-11-24 12:09:19','fasf','saff',93,''),(25,12,'admin/uploads/8974_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-11-24 12:24:38','fgs','gs',93,''),(26,13,'admin/uploads/9035_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-11-24 12:51:44','q','q',93,''),(27,13,'admin/uploads/4503_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-11-24 12:52:44','fasfaf','fasf',93,''),(28,13,'admin/uploads/7827_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-11-24 12:54:20','ffsafsfafsaf','fsa',93,''),(29,13,'admin/uploads/6680_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-11-24 13:02:49','jkl','jkl',93,''),(30,14,'admin/uploads/1457_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-11-24 13:06:56','fasf','saf',93,''),(31,16,'admin/uploads/7151_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-11-25 10:39:52','test','my_assginment',93,''),(32,17,'admin/uploads/1918_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-11-25 15:54:19','q','q',71,'95'),(33,31,'admin/uploads/7519_File_win_boot_screen_16_9_by_medi_dadu-d4s7dc1.gif','2013-12-07 20:58:58','dad','das',75,''),(34,20,'admin/uploads/2416_File_about.php','2014-01-14 08:51:53','Asssd','Assignment1',136,''),(35,20,'admin/uploads/5560_File_Chrysanthemum.jpg','2014-01-14 08:52:22','sder','sfew',136,'98');

/*Table structure for table `student_backpack` */

DROP TABLE IF EXISTS `student_backpack`;

CREATE TABLE `student_backpack` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `floc` varchar(100) NOT NULL,
  `fdatein` varchar(100) NOT NULL,
  `fdesc` varchar(100) NOT NULL,
  `student_id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `student_backpack` */

insert  into `student_backpack`(`file_id`,`floc`,`fdatein`,`fdesc`,`student_id`,`fname`) values (1,'admin/uploads/2658_File_kevin.docx','2014-02-13 11:11:50','test',210,'test');

/*Table structure for table `student_class_quiz` */

DROP TABLE IF EXISTS `student_class_quiz`;

CREATE TABLE `student_class_quiz` (
  `student_class_quiz_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_quiz_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `student_quiz_time` varchar(100) NOT NULL,
  `grade` varchar(100) NOT NULL,
  PRIMARY KEY (`student_class_quiz_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `student_class_quiz` */

insert  into `student_class_quiz`(`student_class_quiz_id`,`class_quiz_id`,`student_id`,`student_quiz_time`,`grade`) values (1,15,107,'3594','0 out of 2'),(2,16,136,'3600','0 out of 0'),(3,15,76,'1793',''),(4,16,93,'767',''),(5,14,107,'3594',''),(6,15,75,'3571','2 out of 2'),(7,14,75,'3571','1 out of 2'),(8,13,75,'3571','2 out of 2');

/*Table structure for table `subject` */

DROP TABLE IF EXISTS `subject`;

CREATE TABLE `subject` (
  `subject_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_code` varchar(100) NOT NULL,
  `subject_title` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `description` longtext NOT NULL,
  `unit` int(11) NOT NULL,
  `Pre_req` varchar(100) NOT NULL,
  `semester` varchar(100) NOT NULL,
  `class_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`subject_id`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;

/*Data for the table `subject` */

insert  into `subject`(`subject_id`,`subject_code`,`subject_title`,`category`,`description`,`unit`,`Pre_req`,`semester`,`class_id`) values (14,'IS 411A','Senior Systems Project 1','','<p><span style=\"font-size:medium\"><em>About the Subject</em></span></p>\r\n\r\n<p>This subject comprisea topics about systems development, SDLC methodologies, Conceptual Framework, diagrams such as DFD, ERD and Flowchart and writing a thesis proposal.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>The project requirement for this subject are:</p>\r\n\r\n<p>Chapters (1-5) Thesis Proposal</p>\r\n\r\n<p>100% Running System at the end of semester</p>\r\n\r\n<p>&nbsp;</p>\r\n',3,'','',13),(15,'IS 412','Effective Human Communication for IT Professional','','<p><span style=\"font-size: medium;\"><em>About the Subject</em></span></p>\r\n<p>This subject is intended for IT students to develop or enhance communication skills that will be beneficial especially when used in the business industry. The lesson includes Verbal Communication (Written and Oral), Non-verbal Communication, etc.</p>',3,'','',14),(16,'IS 311','Programming Languages','','<pre class=\"coursera-course-heading\" data-msg=\"coursera-course-about\"><span style=\"font-size: medium;\"><em>About the Subject</em></span></pre>\r\n<div class=\"coursera-course-detail\" data-user-generated=\"data-user-generated\">Learn many of the concepts that underlie all programming languages. Develop a programming style known as functional programming and contrast it with object-oriented programming. Through experience writing programs and studying three different languages, learn the key issues in designing and using programming languages, such as modularity and the complementary benefits of static and dynamic typing. This course is neither particularly theoretical nor just about programming specifics &ndash; it will give you a framework for understanding how to use language constructs effectively and how to design correct and elegant programs. By using different languages, you learn to think more deeply than in terms of the particular syntax of one language. The emphasis on functional programming is essential for learning how to write robust, reusable, composable, and elegant programs &ndash; in any language.</div>\r\n<h2 class=\"coursera-course-detail\" data-user-generated=\"data-user-generated\">&nbsp;</h2>\r\n<pre class=\"coursera-course-detail\" data-user-generated=\"data-user-generated\"><span style=\"font-size: medium;\"><em>&nbsp;Course Syllabus</em></span></pre>\r\n<div class=\"coursera-course-detail\" data-user-generated=\"data-user-generated\">\r\n<ul>\r\n<li>Syntax vs. semantics vs. idioms vs. libraries vs. tools</li>\r\n<li>ML basics (bindings, conditionals, records, functions)</li>\r\n<li>Recursive functions and recursive types</li>\r\n<li>Benefits of no mutation</li>\r\n<li>Algebraic datatypes, pattern matching</li>\r\n<li>Tail recursion</li>\r\n<li>First-class functions and function closures</li>\r\n<li>Lexical scope</li>\r\n<li>Equivalence and effects</li>\r\n<li>Parametric polymorphism and container types</li>\r\n<li>Type inference</li>\r\n<li>Abstract types and modules</li>\r\n<li>Racket basics</li>\r\n<li>Dynamic vs. static typing</li>\r\n<li>Implementing languages, especially higher-order functions</li>\r\n<li>Macro</li>\r\n<li>Ruby basics</li>\r\n<li>Object-oriented programming</li>\r\n<li>Pure object-orientation</li>\r\n<li>Implementing dynamic dispatch</li>\r\n<li>Multiple inheritance, interfaces, and mixins</li>\r\n<li>OOP vs. functional decomposition and extensibility</li>\r\n<li>Subtyping for records, functions, and objects</li>\r\n<li>Subtyping</li>\r\n<li>Class-based subtyping</li>\r\n<li>Subtyping vs. parametric polymorphism; bounded polymorphism</li>\r\n</ul>\r\n</div>',3,'','',15),(17,'IS 413','Introduction to the IM Professional and Ethics','','<p>This subject discusses about Ethics, E-Commerce, Cybercrime Law, Computer Security, etc.</p>',0,'','',14),(22,'IS 221','Application Development','','',3,'','2nd',21),(23,'IS 222','Network and Internet Technology','','',3,'','2nd',15),(24,'IS 223','Business Process','','',3,'','2nd',13),(25,'IS 224','Discrete Structures','','',3,'','2nd',13),(26,'IS 227','IS Programming 2','','',3,'','2nd',13),(28,'LIT 1','English  Literature','','',3,'','2nd',14),(29,'ACCTG 2','Fundamentals of Accounting 2','','',3,'','2nd',14),(30,'PE 4','Team Sports','','',3,'','2nd',15),(31,'IS 302','Survey of Programming Languages','','',3,'','2nd',26),(32,'IS 303','Structured Query Language','','',3,'','2nd',13),(33,'IS 321','Information System Planning','','',3,'','2nd',13),(34,'IS 322','Management of Technology','','',3,'','2nd',15),(35,'IS 323','E-commerce Strategy Architectural','','',3,'','2nd',14),(36,'IS 324','System Analysis and Design','','',3,'','2nd',13),(37,'Law 1','Law on Obligation and Contracts','','',3,'','2nd',7),(38,'Philo 1','Social Philosophy & Logic','','',3,'','2nd',7),(39,'MQTB','Quantitative Techniques in Business','','',3,'','2nd',8),(40,'GNS 201','Current Affairs','','<p>COURSE OUTLINE<br />\r\n1. Course Code : GNS 201</p>\r\n\r\n<p>2. Course Title &nbsp;: Current Affairs<br />\r\n3. Pre-requisite : none<br />\r\n5. Credit/ Class Schedule : 3 units; 3 hrs/week<br />\r\n6. Course Description&nbsp;<br />\r\n<em>Current Affairs</em> is defined as a genre of broadcast journalism where the emphasis is on detailed analysis and discussion of news stories that have recently occurred or are ongoing at the time of broadcast.<br />\r\n<br />\r\nCourse Evaluation:<br />\r\n<br />\r\n1. Quizzes : 30 %<br />\r\n2. Exams : 40 %<br />\r\n3. Class Standing : 20 %<br />\r\n- recitation<br />\r\n- attendance<br />\r\n- behavior<br />\r\n4. Final Grade<br />\r\n- 40 % previous grade<br />\r\n- 60 % current grade</p>\r\n',3,'','2nd',8),(41,'IS 411B','Senior Systems Project 2','','',3,'','2nd',8),(42,'ITC 1','ITC ','','<p>ITC TEST 1</p>\r\n',6,'','2nd',7);

/*Table structure for table `tbl_topic` */

DROP TABLE IF EXISTS `tbl_topic`;

CREATE TABLE `tbl_topic` (
  `topic_Id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `content` text,
  `datetime_posted` timestamp NULL DEFAULT NULL,
  `subject_Id` int(11) DEFAULT NULL,
  PRIMARY KEY (`topic_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

/*Data for the table `tbl_topic` */

insert  into `tbl_topic`(`topic_Id`,`title`,`content`,`datetime_posted`,`subject_Id`) values (11,'How to select your first programming language','<p><iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/2EaopRDxNrw\" frameborder=\"0\" allow=\"autoplay; encrypted-media\" allowfullscreen></iframe></p>\n<p>edited</p>','2015-05-16 05:10:49',189),(13,'ROMANTIC POETRY2','<p><iframe src=\"https://www.youtube.com/embed/7VG1GHCpgNE\" width=\"560\" height=\"315\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>','2018-07-28 10:04:12',189),(20,'DJKING','<p><iframe src=\"https://www.youtube.com/embed/IKEYNgFFI-Q\" width=\"560\" height=\"315\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>\r\n<p>HEllo This is the Quiz prepeartion Module Video Check this and Leave a Quesiton or Message after this.</p>','2018-07-28 10:05:49',190);

/*Table structure for table `teacher` */

DROP TABLE IF EXISTS `teacher`;

CREATE TABLE `teacher` (
  `teacher_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `department_id` int(11) NOT NULL,
  `location` varchar(200) NOT NULL,
  `about` varchar(500) NOT NULL,
  `teacher_status` varchar(20) NOT NULL,
  `teacher_stat` varchar(100) NOT NULL,
  PRIMARY KEY (`teacher_id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

/*Data for the table `teacher` */

insert  into `teacher`(`teacher_id`,`username`,`password`,`firstname`,`lastname`,`department_id`,`location`,`about`,`teacher_status`,`teacher_stat`) values (9,'1001','test','Jerry','Philip',4,'uploads/PABUAYA.jpg','','Registered','Activated'),(5,'1002','red','Ayo','Tunde',4,'uploads/redoblo.JPG','','','Activated'),(11,'1003','aladin','Ahmed','Tunde',4,'uploads/cabrera.jpg','','','Activated'),(13,'test','test','Raphael','George',4,'uploads/CADAGAT.JPG','','','Activated'),(12,'1000','test','Funmi','Adeleke',4,'uploads/shhhh.jpg','<p style=\"text-align: justify;\">Has taught programming languages at the University of Washington since 2003. During his 10 years as a faculty member, his department&rsquo;s undergraduate students have elected him &ldquo;teacher of the year&rdquo; twice and awarded him second place once. His research, resulting in over 50 peer-reviewed publications, has covered the theory, design, and implementation of programming languages, as well as connections to computer architecture and softwar','','Activated'),(14,'honey','lee','Aisha','Olatubosu',4,'uploads/HONEY.jpg','','','Activated'),(15,'chaw','chaw','Charles','Peter',4,'uploads/NO-IMAGE-AVAILABLE.jpg','','','Activated'),(17,'','','Lovelyn ','Adesuwa',5,'uploads/NO-IMAGE-AVAILABLE.jpg','','','Activated'),(18,'test123','test123','Ahmad','Deola',4,'uploads/449E26DB.jpg','','Registered','Activated'),(19,'2002','12345','Daniel','Lamido',4,'uploads/NO-IMAGE-AVAILABLE.jpg','','Registered','Deactivated'),(20,'','','Muhammad Ahmad','Naeem',9,'uploads/NO-IMAGE-AVAILABLE.jpg','','','Activated'),(23,'2001','12345','Mohsin','Abbas',10,'uploads/NO-IMAGE-AVAILABLE.jpg','','Registered',''),(22,'Ahmad123','test','Ahmad','Naeem',10,'uploads/NO-IMAGE-AVAILABLE.jpg','','Registered','Activated');

/*Table structure for table `teacher_backpack` */

DROP TABLE IF EXISTS `teacher_backpack`;

CREATE TABLE `teacher_backpack` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `floc` varchar(100) NOT NULL,
  `fdatein` varchar(100) NOT NULL,
  `fdesc` varchar(100) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `teacher_backpack` */

/*Table structure for table `teacher_class` */

DROP TABLE IF EXISTS `teacher_class`;

CREATE TABLE `teacher_class` (
  `teacher_class_id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `thumbnails` varchar(100) NOT NULL,
  `school_year` varchar(100) NOT NULL,
  PRIMARY KEY (`teacher_class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=197 DEFAULT CHARSET=latin1;

/*Data for the table `teacher_class` */

insert  into `teacher_class`(`teacher_class_id`,`teacher_id`,`class_id`,`subject_id`,`thumbnails`,`school_year`) values (97,9,7,15,'admin/uploads/thumbnails.jpg','2012-2013'),(135,0,22,29,'admin/uploads/thumbnails.jpg','2013-2014'),(151,5,7,14,'admin/uploads/thumbnails.jpg','2013-2014'),(152,5,8,14,'admin/uploads/thumbnails.jpg','2013-2014'),(153,5,13,36,'admin/uploads/thumbnails.jpg','2013-2014'),(157,18,15,23,'admin/uploads/thumbnails.jpg','2013-2014'),(158,18,16,23,'admin/uploads/thumbnails.jpg','2013-2014'),(159,18,12,23,'admin/uploads/thumbnails.jpg','2013-2014'),(160,18,7,29,'admin/uploads/thumbnails.jpg','2013-2014'),(165,134,15,23,'admin/uploads/thumbnails.jpg','2013-2014'),(167,12,13,35,'admin/uploads/thumbnails.jpg','2013-2014'),(168,12,14,35,'admin/uploads/thumbnails.jpg','2013-2014'),(170,12,16,24,'admin/uploads/thumbnails.jpg','2013-2014'),(172,18,13,39,'admin/uploads/thumbnails.jpg','2013-2014'),(173,18,14,39,'admin/uploads/thumbnails.jpg','2013-2014'),(174,13,12,16,'admin/uploads/thumbnails.jpg','2013-2014'),(175,13,13,16,'admin/uploads/thumbnails.jpg','2013-2014'),(176,13,14,16,'admin/uploads/thumbnails.jpg','2013-2014'),(177,14,12,32,'admin/uploads/thumbnails.jpg','2013-2014'),(178,14,13,32,'admin/uploads/thumbnails.jpg','2013-2014'),(179,14,14,32,'admin/uploads/thumbnails.jpg','2013-2014'),(180,19,13,22,'admin/uploads/thumbnails.jpg','2013-2014'),(181,12,20,24,'admin/uploads/thumbnails.jpg','2013-2014'),(183,12,18,24,'admin/uploads/thumbnails.jpg','2013-2014'),(184,12,17,25,'admin/uploads/thumbnails.jpg','2013-2014'),(185,12,7,22,'admin/uploads/thumbnails.jpg','2013-2014'),(186,15,18,22,'admin/uploads/thumbnails.jpg','2013-2014'),(187,9,18,40,'admin/uploads/thumbnails.jpg','2013-2014'),(188,75,13,35,'admin/uploads/thumbnails.jpg','2017-2018'),(189,12,24,17,'admin/uploads/thumbnails.jpg','2017-2018'),(190,22,25,42,'admin/uploads/thumbnails.jpg','2017-2018'),(192,9,26,45,'admin/uploads/thumbnails.jpg','2017-2018'),(193,9,26,47,'admin/uploads/thumbnails.jpg','2017-2018'),(194,9,26,46,'admin/uploads/thumbnails.jpg','2017-2018'),(195,23,26,31,'admin/uploads/thumbnails.jpg','2017-2018'),(196,23,21,22,'admin/uploads/thumbnails.jpg','2017-2018');

/*Table structure for table `teacher_class_announcements` */

DROP TABLE IF EXISTS `teacher_class_announcements`;

CREATE TABLE `teacher_class_announcements` (
  `teacher_class_announcements_id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(500) NOT NULL,
  `teacher_id` varchar(100) NOT NULL,
  `teacher_class_id` int(11) NOT NULL,
  `date` varchar(50) NOT NULL,
  PRIMARY KEY (`teacher_class_announcements_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

/*Data for the table `teacher_class_announcements` */

insert  into `teacher_class_announcements`(`teacher_class_announcements_id`,`content`,`teacher_id`,`teacher_class_id`,`date`) values (2,'<p><strong>Project Deadline</strong></p>\r\n\r\n<p>In December 1st week&nbsp; system must fully functioning.</p>\r\n\r\n<p><br />\r\n&nbsp;</p>\r\n','9',87,'2013-10-30 13:21:13'),(21,'<p>Test is next week</p>\r\n','9',87,'2013-10-30 14:33:21'),(31,'<p>Hi everyone</p>\r\n','9',87,'2013-10-30 15:41:56'),(33,'<p>hello students</p>\r\n','9',95,'2013-10-30 17:44:28'),(34,'<p>hello guys</p>\r\n','9',95,'2013-11-02 10:51:39'),(35,'<p>Exam is next week</p>\r\n','12',147,'2013-11-16 13:59:33'),(36,'<p>CS 1A: Submit assignment tomorrow before 1pm.</p>\r\n','12',154,'2013-11-18 15:29:34'),(37,'<p>Mock exam is tomorrow<br />\r\n&nbsp;</p>\r\n','12',167,'2014-01-17 14:36:32'),(38,'<p>Welcome back students<img alt=\"sad\" src=\"http://localhost/lms/admin/vendors/ckeditor/plugins/smiley/images/sad_smile.gif\" style=\"height:20px; width:20px\" title=\"sad\" /></p>\r\n','12',167,'2014-02-13 13:45:59'),(39,'<p>Hello world</p>\r\n','12',189,'2018-07-24 21:26:26');

/*Table structure for table `teacher_class_student` */

DROP TABLE IF EXISTS `teacher_class_student`;

CREATE TABLE `teacher_class_student` (
  `teacher_class_student_id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_class_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  PRIMARY KEY (`teacher_class_student_id`)
) ENGINE=InnoDB AUTO_INCREMENT=414 DEFAULT CHARSET=latin1;

/*Data for the table `teacher_class_student` */

insert  into `teacher_class_student`(`teacher_class_student_id`,`teacher_class_id`,`student_id`,`teacher_id`) values (31,165,141,134),(32,165,134,134),(54,167,113,12),(55,167,112,12),(57,167,108,12),(58,167,105,12),(59,167,106,12),(60,167,103,12),(61,167,104,12),(62,167,100,12),(63,167,101,12),(64,167,102,12),(65,167,97,12),(66,167,98,12),(67,167,95,12),(68,167,94,12),(69,167,76,12),(70,167,107,12),(71,167,110,12),(73,167,99,12),(74,167,96,12),(75,167,75,12),(76,167,74,12),(77,167,73,12),(78,167,72,12),(79,167,71,12),(80,168,135,12),(81,168,140,12),(82,168,162,12),(83,168,164,12),(84,168,165,12),(85,168,166,12),(86,168,167,12),(87,168,168,12),(88,168,169,12),(89,168,172,12),(90,168,171,12),(91,168,173,12),(92,168,174,12),(93,168,175,12),(94,168,176,12),(95,168,177,12),(96,168,178,12),(97,168,179,12),(98,168,180,12),(99,168,181,12),(100,168,182,12),(101,168,183,12),(102,168,206,12),(103,168,207,12),(127,172,113,18),(128,172,112,18),(129,172,111,18),(130,172,108,18),(131,172,105,18),(132,172,106,18),(133,172,103,18),(134,172,104,18),(135,172,100,18),(136,172,101,18),(137,172,102,18),(138,172,97,18),(139,172,98,18),(140,172,95,18),(141,172,94,18),(142,172,76,18),(143,172,107,18),(144,172,110,18),(146,172,99,18),(147,172,96,18),(148,172,75,18),(149,172,74,18),(150,172,73,18),(151,172,72,18),(152,172,71,18),(153,173,135,18),(154,173,140,18),(155,173,162,18),(156,173,164,18),(157,173,165,18),(158,173,166,18),(159,173,167,18),(160,173,168,18),(161,173,169,18),(162,173,172,18),(163,173,171,18),(164,173,173,18),(165,173,174,18),(166,173,175,18),(167,173,176,18),(168,173,177,18),(169,173,178,18),(170,173,179,18),(171,173,180,18),(172,173,181,18),(173,173,182,18),(174,173,183,18),(175,173,206,18),(176,173,207,18),(177,174,134,13),(178,174,142,13),(179,174,143,13),(180,174,144,13),(181,174,145,13),(182,174,146,13),(183,174,147,13),(184,174,148,13),(185,174,149,13),(186,174,150,13),(187,174,151,13),(188,174,152,13),(189,174,153,13),(190,174,154,13),(191,174,155,13),(192,174,156,13),(193,174,157,13),(194,174,158,13),(195,174,159,13),(196,175,113,13),(197,175,112,13),(198,175,111,13),(199,175,108,13),(200,175,105,13),(201,175,106,13),(202,175,103,13),(203,175,104,13),(204,175,100,13),(205,175,101,13),(206,175,102,13),(207,175,97,13),(208,175,98,13),(209,175,95,13),(210,175,94,13),(211,175,76,13),(212,175,107,13),(213,175,110,13),(215,175,99,13),(216,175,96,13),(217,175,75,13),(218,175,74,13),(219,175,73,13),(220,175,72,13),(221,175,71,13),(222,176,135,13),(223,176,140,13),(224,176,162,13),(225,176,164,13),(226,176,165,13),(227,176,166,13),(228,176,167,13),(229,176,168,13),(230,176,169,13),(231,176,172,13),(232,176,171,13),(233,176,173,13),(234,176,174,13),(235,176,175,13),(236,176,176,13),(237,176,177,13),(238,176,178,13),(239,176,179,13),(240,176,180,13),(241,176,181,13),(242,176,182,13),(243,176,183,13),(244,176,206,13),(245,176,207,13),(246,177,134,14),(247,177,142,14),(248,177,143,14),(249,177,144,14),(250,177,145,14),(251,177,146,14),(252,177,147,14),(253,177,148,14),(254,177,149,14),(255,177,150,14),(256,177,151,14),(257,177,152,14),(258,177,153,14),(259,177,154,14),(260,177,155,14),(261,177,156,14),(262,177,157,14),(263,177,158,14),(264,177,159,14),(265,178,113,14),(266,178,112,14),(267,178,111,14),(268,178,108,14),(269,178,105,14),(270,178,106,14),(271,178,103,14),(272,178,104,14),(273,178,100,14),(274,178,101,14),(275,178,102,14),(276,178,97,14),(277,178,98,14),(278,178,95,14),(279,178,94,14),(280,178,76,14),(281,178,107,14),(282,178,110,14),(284,178,99,14),(285,178,96,14),(286,178,75,14),(287,178,74,14),(288,178,73,14),(289,178,72,14),(290,178,71,14),(291,179,135,14),(292,179,140,14),(293,179,162,14),(294,179,164,14),(295,179,165,14),(296,179,166,14),(297,179,167,14),(298,179,168,14),(299,179,169,14),(300,179,172,14),(301,179,171,14),(302,179,173,14),(303,179,174,14),(304,179,175,14),(305,179,176,14),(306,179,177,14),(307,179,178,14),(308,179,179,14),(309,179,180,14),(310,179,181,14),(311,179,182,14),(312,179,183,14),(313,179,206,14),(314,179,207,14),(315,180,113,19),(316,180,112,19),(317,180,111,19),(318,180,108,19),(319,180,105,19),(320,180,106,19),(321,180,103,19),(322,180,104,19),(323,180,100,19),(324,180,101,19),(325,180,102,19),(326,180,97,19),(327,180,98,19),(328,180,95,19),(329,180,94,19),(330,180,76,19),(331,180,107,19),(332,180,110,19),(334,180,99,19),(335,180,96,19),(336,180,75,19),(337,180,74,19),(338,180,73,19),(339,180,72,19),(340,180,71,19),(341,181,209,12),(342,181,210,12),(345,183,213,12),(346,183,214,12),(347,183,215,12),(348,183,216,12),(349,184,184,12),(350,184,185,12),(351,184,186,12),(352,184,187,12),(353,184,188,12),(354,184,189,12),(355,184,190,12),(356,184,191,12),(358,184,193,12),(359,184,194,12),(360,184,195,12),(361,184,196,12),(362,184,197,12),(363,184,198,12),(364,184,199,12),(365,184,200,12),(366,184,201,12),(367,184,202,12),(368,184,203,12),(369,184,204,12),(370,184,205,12),(371,184,217,12),(372,184,192,12),(373,185,93,12),(374,185,136,12),(375,185,138,12),(376,185,139,12),(377,185,211,12),(378,186,214,15),(379,186,219,15),(380,187,214,9),(381,187,219,9),(382,187,113,9),(383,188,113,75),(384,188,112,75),(385,188,111,75),(386,188,108,75),(387,188,105,75),(388,188,106,75),(389,188,103,75),(390,188,104,75),(391,188,100,75),(392,188,101,75),(393,188,102,75),(394,188,97,75),(395,188,98,75),(396,188,95,75),(397,188,94,75),(398,188,76,75),(399,188,107,75),(400,188,110,75),(402,188,99,75),(403,188,96,75),(404,188,75,75),(405,188,74,75),(406,188,73,75),(407,188,72,75),(408,188,71,75),(409,189,113,12),(410,189,112,12),(411,189,75,12),(412,190,221,22),(413,195,223,23);

/*Table structure for table `teacher_notification` */

DROP TABLE IF EXISTS `teacher_notification`;

CREATE TABLE `teacher_notification` (
  `teacher_notification_id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_class_id` int(11) NOT NULL,
  `notification` varchar(100) NOT NULL,
  `date_of_notification` varchar(100) NOT NULL,
  `link` varchar(100) NOT NULL,
  `student_id` int(11) NOT NULL,
  `assignment_id` int(11) NOT NULL,
  PRIMARY KEY (`teacher_notification_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

/*Data for the table `teacher_notification` */

insert  into `teacher_notification`(`teacher_notification_id`,`teacher_class_id`,`notification`,`date_of_notification`,`link`,`student_id`,`assignment_id`) values (15,160,'Submit Assignment file name <b>my_assginment</b>','2013-11-25 10:39:52','view_submit_assignment.php',93,16),(17,161,'Submit Assignment file name <b>q</b>','2013-11-25 15:54:19','view_submit_assignment.php',71,17),(18,190,'Add Downloadable Materials file name <b>Test</b>','2018-07-30 23:10:31','downloadable.php',221,0);

/*Table structure for table `teacher_shared` */

DROP TABLE IF EXISTS `teacher_shared`;

CREATE TABLE `teacher_shared` (
  `teacher_shared_id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` int(11) NOT NULL,
  `shared_teacher_id` int(11) NOT NULL,
  `floc` varchar(100) NOT NULL,
  `fdatein` varchar(100) NOT NULL,
  `fdesc` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  PRIMARY KEY (`teacher_shared_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `teacher_shared` */

insert  into `teacher_shared`(`teacher_shared_id`,`teacher_id`,`shared_teacher_id`,`floc`,`fdatein`,`fdesc`,`fname`) values (1,12,14,'admin/uploads/7939_File_449E26DB.jpg','2014-02-20 09:55:32','sas','sss');

/*Table structure for table `time_slot` */

DROP TABLE IF EXISTS `time_slot`;

CREATE TABLE `time_slot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `time_slot` */

insert  into `time_slot`(`id`,`name`) values (2,'8:30 AM'),(3,'11:30 AM'),(4,'2:30 PM'),(5,'5:30 PM'),(6,'8:30 PM'),(7,'7:00 AM');

/*Table structure for table `user_log` */

DROP TABLE IF EXISTS `user_log`;

CREATE TABLE `user_log` (
  `user_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) NOT NULL,
  `login_date` varchar(30) NOT NULL,
  `logout_date` varchar(30) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`user_log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=latin1;

/*Data for the table `user_log` */

insert  into `user_log`(`user_log_id`,`username`,`login_date`,`logout_date`,`user_id`) values (1,'admin','2013-11-01 11:57:33','2013-11-18 10:33:54',10),(2,'admin','2013-11-05 09:52:09','2013-11-18 10:33:54',10),(3,'admin','2013-11-08 10:41:09','2013-11-18 10:33:54',10),(4,'admin','2013-11-12 22:53:05','2013-11-18 10:33:54',10),(5,'admin','2013-11-13 07:07:04','2013-11-18 10:33:54',10),(6,'admin','2013-11-13 13:07:58','2013-11-18 10:33:54',10),(7,'admin','2013-11-13 13:30:45','2013-11-18 10:33:54',10),(8,'admin','2013-11-13 15:25:20','2013-11-18 10:33:54',10),(9,'admin','2013-11-13 15:46:28','2013-11-18 10:33:54',10),(10,'admin','2013-11-13 16:04:10','2013-11-18 10:33:54',10),(11,'admin','2013-11-13 17:31:37','2013-11-18 10:33:54',10),(12,'admin','2013-11-13 22:47:45','2013-11-18 10:33:54',10),(13,'admin','2013-11-14 10:27:06','2013-11-18 10:33:54',10),(14,'admin','2013-11-14 10:27:55','2013-11-18 10:33:54',10),(15,'admin','2013-11-14 10:38:08','2013-11-18 10:33:54',10),(16,'admin','2013-11-14 10:38:09','2013-11-18 10:33:54',10),(17,'admin','2013-11-14 10:41:06','2013-11-18 10:33:54',10),(18,'admin','2013-11-14 11:44:08','2013-11-18 10:33:54',10),(19,'admin','2013-11-14 21:53:56','2013-11-18 10:33:54',10),(20,'admin','2013-11-14 22:03:53','2013-11-18 10:33:54',10),(21,'admin','2013-11-16 13:40:56','2013-11-18 10:33:54',10),(22,'admin','2013-11-18 10:22:07','2013-11-18 10:33:54',10),(23,'jkev','2013-11-18 10:33:59','2014-02-13 11:19:36',14),(24,'jkev','2013-11-18 15:20:45','2014-02-13 11:19:36',14),(25,'jkev','2013-11-18 15:42:04','2014-02-13 11:19:36',14),(26,'jkev','2013-11-18 16:30:14','2014-02-13 11:19:36',14),(27,'jkev','2013-11-18 16:36:44','2014-02-13 11:19:36',14),(28,'jkev','2013-11-18 17:39:55','2014-02-13 11:19:36',14),(29,'jkev','2013-11-18 20:06:49','2014-02-13 11:19:36',14),(30,'jkev','2013-11-23 08:04:27','2014-02-13 11:19:36',14),(31,'teph','2013-11-23 12:02:27','2013-11-30 21:33:02',13),(32,'teph','2013-11-24 08:55:55','2013-11-30 21:33:02',13),(33,'jkev','2013-11-25 10:32:16','2014-02-13 11:19:36',14),(34,'jkev','2013-11-25 14:33:05','2014-02-13 11:19:36',14),(35,'jkev','2013-11-25 15:02:47','2014-02-13 11:19:36',14),(36,'jkev','2013-11-25 21:08:19','2014-02-13 11:19:36',14),(37,'jkev','2013-11-25 23:49:58','2014-02-13 11:19:36',14),(38,'jkev','2013-11-26 00:32:22','2014-02-13 11:19:36',14),(39,'jkev','2013-11-26 10:39:52','2014-02-13 11:19:36',14),(40,'jkev','2013-11-26 21:48:05','2014-02-13 11:19:36',14),(41,'jkev','2013-11-28 23:00:00','2014-02-13 11:19:36',14),(42,'jkev','2013-11-28 23:00:06','2014-02-13 11:19:36',14),(43,'jkev','2013-11-30 21:28:54','2014-02-13 11:19:36',14),(44,'teph','2013-11-30 21:32:54','2013-11-30 21:33:02',13),(45,'jkev','2013-12-04 12:45:09','2014-02-13 11:19:36',14),(46,'teph','2013-12-04 14:02:19','',13),(47,'jkev','2013-12-11 11:56:15','2014-02-13 11:19:36',14),(48,'jkev','2013-12-11 12:04:44','2014-02-13 11:19:36',14),(49,'jkev','2013-12-12 09:44:34','2014-02-13 11:19:36',14),(50,'jkev','2013-12-13 01:48:23','2014-02-13 11:19:36',14),(51,'jkev','2013-12-27 09:13:20','2014-02-13 11:19:36',14),(52,'jkev','2013-12-27 10:18:38','2014-02-13 11:19:36',14),(53,'jkev','2013-12-27 10:35:43','2014-02-13 11:19:36',14),(54,'jkev','2013-12-27 11:08:54','2014-02-13 11:19:36',14),(55,'jkev','2013-12-27 11:20:25','2014-02-13 11:19:36',14),(56,'jkev','2013-12-27 11:41:58','2014-02-13 11:19:36',14),(57,'jkev','2013-12-27 11:43:10','2014-02-13 11:19:36',14),(58,'jkev','2013-12-27 14:54:57','2014-02-13 11:19:36',14),(59,'jkev','2014-01-12 20:08:26','2014-02-13 11:19:36',14),(60,'jkev','2014-01-13 15:24:07','2014-02-13 11:19:36',14),(61,'jkev','2014-01-13 18:46:08','2014-02-13 11:19:36',14),(62,'jkev','2014-01-15 20:40:15','2014-02-13 11:19:36',14),(63,'jkev','2014-01-16 14:42:02','2014-02-13 11:19:36',14),(64,'jkev','2014-01-17 09:16:17','2014-02-13 11:19:36',14),(65,'jkev','2014-01-17 13:25:51','2014-02-13 11:19:36',14),(66,'admin','2014-01-17 14:41:30','2019-05-15 22:03:35',15),(67,'admin','2014-01-17 15:56:32','2019-05-15 22:03:35',15),(68,'admin','2014-01-26 17:45:31','2019-05-15 22:03:35',15),(69,'admin','2014-02-13 10:45:17','2019-05-15 22:03:35',15),(70,'admin','2014-02-13 11:05:27','2019-05-15 22:03:35',15),(71,'jkev','2014-02-13 11:16:48','2014-02-13 11:19:36',14),(72,'admin','2014-02-13 11:55:36','2019-05-15 22:03:35',15),(73,'admin','2014-02-13 12:32:38','2019-05-15 22:03:35',15),(74,'admin','2014-02-13 12:52:05','2019-05-15 22:03:35',15),(75,'admin','2014-02-13 13:04:35','2019-05-15 22:03:35',15),(76,'jkev','2014-02-13 14:35:27','',14),(77,'admin','2014-02-20 09:40:39','2019-05-15 22:03:35',15),(78,'admin','2014-02-20 09:42:21','2019-05-15 22:03:35',15),(79,'admin','2014-02-27 22:40:15','2019-05-15 22:03:35',15),(80,'admin','2014-02-28 13:12:52','2019-05-15 22:03:35',15),(81,'admin','2014-04-02 17:27:47','2019-05-15 22:03:35',15),(82,'admin','2014-04-03 15:29:38','2019-05-15 22:03:35',15),(83,'admin','2014-06-15 12:31:51','2019-05-15 22:03:35',15),(84,'admin','2017-05-25 05:42:18','2019-05-15 22:03:35',15),(85,'admin','2017-05-25 05:44:15','2019-05-15 22:03:35',15),(86,'admin','2017-05-25 05:44:52','2019-05-15 22:03:35',15),(87,'admin','2017-05-25 08:28:14','2019-05-15 22:03:35',15),(88,'admin','2017-06-04 16:37:23','2019-05-15 22:03:35',15),(89,'admin','2018-03-04 08:04:07','2019-05-15 22:03:35',15),(90,'admin','2018-03-04 09:08:40','2019-05-15 22:03:35',15),(91,'admin','2018-05-24 16:41:00','2019-05-15 22:03:35',15),(92,'admin','2018-05-24 16:46:30','2019-05-15 22:03:35',15),(93,'admin','2018-06-06 02:51:12','2019-05-15 22:03:35',15),(94,'admin','2018-06-06 02:51:13','2019-05-15 22:03:35',15),(95,'admin','2018-06-06 02:57:25','2019-05-15 22:03:35',15),(96,'admin','2018-06-06 03:01:07','2019-05-15 22:03:35',15),(97,'admin','2018-07-23 19:03:26','2019-05-15 22:03:35',15),(98,'admin','2018-07-24 03:43:26','2019-05-15 22:03:35',15),(99,'admin','2018-07-24 03:43:28','2019-05-15 22:03:35',15),(100,'admin','2018-07-24 15:51:36','2019-05-15 22:03:35',15),(101,'admin','2018-07-24 16:07:08','2019-05-15 22:03:35',15),(102,'admin','2018-07-24 16:42:43','2019-05-15 22:03:35',15),(103,'admin','2018-07-30 22:30:49','2019-05-15 22:03:35',15),(104,'admin','2018-07-30 22:37:31','2019-05-15 22:03:35',15),(105,'admin','2018-07-30 22:37:47','2019-05-15 22:03:35',15),(106,'admin','2018-07-30 23:04:25','2019-05-15 22:03:35',15),(107,'admin','2019-04-18 20:48:35','2019-05-15 22:03:35',15),(108,'admin','2019-04-18 22:37:06','2019-05-15 22:03:35',15),(109,'admin','2019-04-18 23:30:05','2019-05-15 22:03:35',15),(110,'admin','2019-04-19 01:56:55','2019-05-15 22:03:35',15),(111,'admin','2019-04-19 02:04:00','2019-05-15 22:03:35',15),(112,'admin','2019-04-20 01:32:14','2019-05-15 22:03:35',15),(113,'admin','2019-04-20 02:09:18','2019-05-15 22:03:35',15),(114,'admin','2019-04-20 02:18:47','2019-05-15 22:03:35',15),(115,'admin','2019-05-06 20:57:00','2019-05-15 22:03:35',15),(116,'admin','2019-05-06 20:57:52','2019-05-15 22:03:35',15),(117,'admin','2019-05-07 20:09:31','2019-05-15 22:03:35',15),(118,'admin','2019-05-08 22:42:34','2019-05-15 22:03:35',15),(119,'admin','2019-05-08 23:53:27','2019-05-15 22:03:35',15),(120,'admin','2019-05-08 23:59:14','2019-05-15 22:03:35',15),(121,'admin','2019-05-09 00:05:19','2019-05-15 22:03:35',15),(122,'admin','2019-05-09 00:23:11','2019-05-15 22:03:35',15),(123,'admin','2019-05-09 15:29:45','2019-05-15 22:03:35',15),(124,'admin','2019-05-09 15:32:55','2019-05-15 22:03:35',15),(125,'admin','2019-05-09 15:38:03','2019-05-15 22:03:35',15),(126,'admin','2019-05-09 15:38:03','2019-05-15 22:03:35',15),(127,'admin','2019-05-09 15:38:03','2019-05-15 22:03:35',15),(128,'admin','2019-05-09 15:38:03','2019-05-15 22:03:35',15),(129,'admin','2019-05-09 15:38:03','2019-05-15 22:03:35',15),(130,'admin','2019-05-09 15:38:03','2019-05-15 22:03:35',15),(131,'admin','2019-05-09 15:38:03','2019-05-15 22:03:35',15),(132,'admin','2019-05-09 15:38:03','2019-05-15 22:03:35',15),(133,'admin','2019-05-09 15:38:03','2019-05-15 22:03:35',15),(134,'admin','2019-05-09 15:38:11','2019-05-15 22:03:35',15),(135,'admin','2019-05-09 15:46:54','2019-05-15 22:03:35',15),(136,'admin','2019-05-09 15:51:45','2019-05-15 22:03:35',15),(137,'admin','2019-05-10 20:14:17','2019-05-15 22:03:35',15),(138,'admin','2019-05-10 22:06:28','2019-05-15 22:03:35',15),(139,'admin','2019-05-10 22:13:25','2019-05-15 22:03:35',15),(140,'admin','2019-05-10 23:25:37','2019-05-15 22:03:35',15),(141,'admin','2019-05-11 21:32:33','2019-05-15 22:03:35',15),(142,'admin','2019-05-11 21:43:35','2019-05-15 22:03:35',15),(143,'admin','2019-05-11 22:08:35','2019-05-15 22:03:35',15),(144,'admin','2019-05-11 22:34:57','2019-05-15 22:03:35',15),(145,'admin','2019-05-14 23:51:22','2019-05-15 22:03:35',15),(146,'admin','2019-05-15 21:34:33','2019-05-15 22:03:35',15),(147,'admin','2019-05-15 22:16:11','',15),(148,'admin','2019-05-15 22:49:58','',15),(149,'admin','2019-05-16 14:55:00','',15);

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

/*Data for the table `users` */

insert  into `users`(`user_id`,`username`,`password`,`firstname`,`lastname`) values (13,'teph','teph','Stephanie','Joyce'),(14,'jkev','jkev','john kevin','lola'),(15,'admin','admin','admin','admin');

/*Table structure for table `venue` */

DROP TABLE IF EXISTS `venue`;

CREATE TABLE `venue` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

/*Data for the table `venue` */

insert  into `venue`(`id`,`name`) values (8,'Hall 1'),(9,'Hall 2'),(10,'Hall 3'),(11,'Hall 4'),(12,'Hall 5'),(13,'Hall 6'),(14,'Hall 7'),(15,'Hall 8'),(16,'Hall 9'),(17,'Hall 10'),(18,'Room 2');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
