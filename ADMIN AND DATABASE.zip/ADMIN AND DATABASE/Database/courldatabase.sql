/*
SQLyog Ultimate v12.09 (64 bit)
MySQL - 10.1.38-MariaDB : Database - courselearndb
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`courselearndb` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `courselearndb`;

/*Table structure for table `tbl_admin` */

DROP TABLE IF EXISTS `tbl_admin`;

CREATE TABLE `tbl_admin` (
  `adm_Id` int(11) NOT NULL AUTO_INCREMENT,
  `adm_user` varchar(255) DEFAULT NULL,
  `adm_pwd` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`adm_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `tbl_admin` */

insert  into `tbl_admin`(`adm_Id`,`adm_user`,`adm_pwd`) values (1,'admin','21232f297a57a5a743894a0e4a801fc3');

/*Table structure for table `tbl_answer` */

DROP TABLE IF EXISTS `tbl_answer`;

CREATE TABLE `tbl_answer` (
  `ans_Id` int(11) NOT NULL AUTO_INCREMENT,
  `answer` varchar(255) DEFAULT NULL,
  `quiz_Id` int(11) DEFAULT NULL,
  `user_Id` int(11) DEFAULT NULL,
  PRIMARY KEY (`ans_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_answer` */

/*Table structure for table `tbl_category` */

DROP TABLE IF EXISTS `tbl_category`;

CREATE TABLE `tbl_category` (
  `cat_Id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`cat_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

/*Data for the table `tbl_category` */

insert  into `tbl_category`(`cat_Id`,`name`,`description`,`image`) values (4,'Programming','                    Programming is the art and science of translating a set of ideas into a program - a list of instructions a computer can follow. The person writing a program is known as a programmer (also a coder).                     ','../images/news5.jpg'),(5,'Database','                    Learn MySQL Database                                           ','../images/news6.jpg'),(6,'Advanced JavaScript',' Client JavaScript programming for developing enhanced single page applications                             \r\n                                                                                                                ','../images/news7.jpg'),(10,'Introduction to English Grammar','  Learn the basics of the English language. Basic grammar rules and syntax                                  \r\n                                ','../images/news4.jpg'),(11,'Introduction to Internet Marketing',' Learn the basics of digital marketing, social media marketing and email marketing                            \r\n                                ','../images/news2.jpg'),(12,'Testing','ADLKJADSLKJASDLKajdlajldjlak                                    \r\n                                ','../images/zic2.png');

/*Table structure for table `tbl_comment` */

DROP TABLE IF EXISTS `tbl_comment`;

CREATE TABLE `tbl_comment` (
  `comment_Id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` text,
  `datetime` datetime DEFAULT NULL,
  `sub_Id` int(11) DEFAULT NULL,
  `user_Id` int(11) DEFAULT NULL,
  PRIMARY KEY (`comment_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `tbl_comment` */

insert  into `tbl_comment`(`comment_Id`,`comment`,`datetime`,`sub_Id`,`user_Id`) values (1,'How do I sign up','2015-06-01 07:48:26',0,0),(2,'I can\'t login','2015-06-01 07:48:56',0,0);

/*Table structure for table `tbl_contact` */

DROP TABLE IF EXISTS `tbl_contact`;

CREATE TABLE `tbl_contact` (
  `contact_Id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` text,
  `subject` varchar(255) DEFAULT NULL,
  `message` text,
  PRIMARY KEY (`contact_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `tbl_contact` */

insert  into `tbl_contact`(`contact_Id`,`name`,`email`,`phone`,`subject`,`message`) values (2,'asd','sample@gmail.com','343','sa','sadas'),(3,'asd','asdh@yahoo.com','324','asd','asdaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'),(4,'Sample','asdh@yahoo.com','24','asd','asd'),(5,'Muhammad Ahmad Naeem','m.dj4041@ucp.edu.pk','2147483647','Query','HELlo'),(6,'Muhammad Ahmad Naeem','m.djking@yahoo.com','2147483647','QEE','jdsklfjl'),(7,'Muhammad Ahmad Naeem','m.dj4041@gmail.com','03364224242','SSLDL','LKJLLJ');

/*Table structure for table `tbl_quiz` */

DROP TABLE IF EXISTS `tbl_quiz`;

CREATE TABLE `tbl_quiz` (
  `quiz_Id` int(11) NOT NULL AUTO_INCREMENT,
  `question_name` text,
  `answer1` varchar(255) DEFAULT '',
  `answer2` varchar(255) DEFAULT NULL,
  `answe3` varchar(255) DEFAULT NULL,
  `answer4` varchar(255) DEFAULT NULL,
  `answer` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`quiz_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `tbl_quiz` */

insert  into `tbl_quiz`(`quiz_Id`,`question_name`,`answer1`,`answer2`,`answe3`,`answer4`,`answer`) values (1,'<pre>\r\n<span style=\"color:rgb(0, 136, 0)\">What does PHP stand for?</span></pre>\r\n','4','','','',''),(2,'<pre>\r\n<span style=\"color:rgb(0, 136, 0)\">What does PHP stand for?</span></pre>\r\n','Personal Home Page','Personal Hypertext Processor','Private Home Page','PHP: Hypertext Preprocessor','4'),(3,'<p>asd</p>\r\n','asd','asd','asd','asd','3'),(4,'<p>asd</p>\r\n','45','45','45','452','2'),(5,'<p>asd</p>\r\n','gfgf','fg','fg','fg','2'),(6,'<p>Test Question</p>\r\n','1) A','2) B','3) C','4) D','1) A');

/*Table structure for table `tbl_subtopic` */

DROP TABLE IF EXISTS `tbl_subtopic`;

CREATE TABLE `tbl_subtopic` (
  `sub_Id` int(11) NOT NULL AUTO_INCREMENT,
  `sub_title` varchar(255) DEFAULT NULL,
  `sub_content` text,
  `datetime` datetime DEFAULT NULL,
  `topic_Id` int(11) DEFAULT NULL,
  PRIMARY KEY (`sub_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `tbl_subtopic` */

insert  into `tbl_subtopic`(`sub_Id`,`sub_title`,`sub_content`,`datetime`,`topic_Id`) values (1,'How to select your first programming language','<p><iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/2EaopRDxNrw\" frameborder=\"0\" allow=\"autoplay; encrypted-media\" allowfullscreen></p>\r\n<p>asdasd</p>','2015-05-31 09:46:27',11),(2,'Best programming Languages','<h3>2018 programming languages</h3>\r\n\r\n<p>Latest programming languages</p>\r\n','2015-05-31 06:00:53',11);

/*Table structure for table `tbl_teacher` */

DROP TABLE IF EXISTS `tbl_teacher`;

CREATE TABLE `tbl_teacher` (
  `teacher_Id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(255) DEFAULT NULL,
  `mname` varchar(255) DEFAULT NULL,
  `lname` varchar(255) DEFAULT NULL,
  `uname` varchar(255) DEFAULT NULL,
  `pwd` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`teacher_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `tbl_teacher` */

insert  into `tbl_teacher`(`teacher_Id`,`fname`,`mname`,`lname`,`uname`,`pwd`) values (1,'Arjun','Khan','Aaran','teacher','e10adc3949ba59abbe56e057f20f883e'),(7,'Mike','Daniel','Donald','teacher','teacher');

/*Table structure for table `tbl_topic` */

DROP TABLE IF EXISTS `tbl_topic`;

CREATE TABLE `tbl_topic` (
  `topic_Id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `content` text,
  `datetime_posted` timestamp NULL DEFAULT NULL,
  `cat_Id` int(11) DEFAULT NULL,
  PRIMARY KEY (`topic_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

/*Data for the table `tbl_topic` */

insert  into `tbl_topic`(`topic_Id`,`title`,`content`,`datetime_posted`,`cat_Id`) values (11,'How to select your first programming language','<p><iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/2EaopRDxNrw\" frameborder=\"0\" allow=\"autoplay; encrypted-media\" allowfullscreen></iframe></p>\n<p>edited</p>','2015-05-16 10:10:49',3),(13,'Computer programming','<p>Introduction to computer programming</p>\r\n','2015-05-30 08:37:01',4),(14,'Introduction to SQL','<p>SQL is a Structured Query Language</p>\r\n','2018-06-03 11:28:31',5),(15,'Javascript Variables','<p>var firstname = \"john\";</p>\r\n<p><iframe src=\"https://www.youtube.com/embed/LEx2bL3_5Z8\" width=\"560\" height=\"315\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>','2018-06-24 03:36:15',6),(16,'Javascript Operators','<p>+ Addition Operator</p>\r\n<p>- Subtraction Operator</p>\r\n<p>/ Division Operator<br /> &nbsp;<iframe src=\"https://www.youtube.com/embed/Hl-r8REgLps\" width=\"560\" height=\"315\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>','2018-06-24 12:44:31',6),(17,'DJKING','<p style=\"text-align: center;\"><span style=\"font-size:24px\"><span style=\"background-color:#40E0D0\">Welcome Course</span></span></p>\r\n\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n\r\n<h2 style=\"font-style:italic;\">TEsstt asdaljsdkasjdklasjdlkasj dlaskd</h2>\r\n\r\n<p>&nbsp;</p>\r\n','2018-06-24 03:59:11',12),(18,'ROMANTIC POETRY','<p>afdsfafdafasdfasfd</p>\r\n','2018-07-28 09:20:04',5);

/*Table structure for table `tbl_user` */

DROP TABLE IF EXISTS `tbl_user`;

CREATE TABLE `tbl_user` (
  `user_Id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(255) DEFAULT NULL,
  `mname` varchar(255) DEFAULT NULL,
  `lname` varchar(255) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `tbl_user` */

insert  into `tbl_user`(`user_Id`,`fname`,`mname`,`lname`,`dob`,`gender`,`username`,`password`) values (1,'John','Stanley','Doe','2015-05-20','Male','sample','5e8ff9bf55ba3508199d22e984129be6'),(2,'Jessica','Esther','Edmund','2015-05-08','Female','test','098f6bcd4621d373cade4e832627b4f6'),(3,'Shuaib','Jamal','Khan','2015-05-07','Male','aaa','47bce5c74f589f4867dbd57e9ca9f808'),(4,'Ahmed','Mohammed','Abdul','2015-04-30','Male','lorem','d2e16e6ef52a45b7468f1da56bba1953'),(5,'Ibrahim','Abdul','Salah','0000-00-00','Male','salah123','6de7920174f1a90eacb3a270d9e2a735'),(6,'Vihaan','Arjun','Aditya','0000-00-00','Male','vihaan123','25728f0ece50da64a53bdc6353b8f48a'),(7,'Muhammad Ahmad','','Naeem','1995-12-12','Male','ASD','b2ef9c7b10eb0985365f913420ccb84a');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
